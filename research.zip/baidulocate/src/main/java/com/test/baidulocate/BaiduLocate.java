package com.test.baidulocate;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.sankuai.locate.BaiduEncode;
import com.sankuai.locate.CellData;
import com.sankuai.locate.WifiData;

public class BaiduLocate {

    private static List<CellData> listCellData = new ArrayList<CellData>();

    private static List<WifiData> listWifiData = new ArrayList<WifiData>();

    private static String strDeviceID = "355921043431889";
    private static String strModelNumber = "Nexus S";

    private static void initgsmcelldata() {
        // init cell id
        // 百度定位只有一组cell数据
        CellData celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 9659;
        celldata.cid = 26013;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
    }
    private static void initwcdmacelldata() {
        // init cell id
        // 百度定位只有一组cell数据
        CellData celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 1;
//        celldata.lac = 47872;
//        celldata.cid = 268435455;
      celldata.lac = 47888;
      celldata.cid = 202389741;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
    }
    private static void initcdmacelldata() {
        // init cell id
        CellData celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 13824;
        celldata.lac = 1;
        celldata.cid = 1400;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
    }

    private static void initwifidata() {
        String[] mac = new String[] { "00:27:22:6c:14:18", "6c:e8:73:d0:c3:8c",
                "e4:ce:8f:23:02:fc", "e4:ce:8f:4a:90:68", "02:27:22:6c:14:18",
                "00:27:22:6c:14:9e", "60:c5:47:9a:28:6c", "02:27:22:6c:14:9e",
                "00:27:22:6c:14:a4", "02:27:22:6c:14:a4", "00:27:22:b7:6d:2b",
                "06:27:22:b7:6d:2b", "b8:8d:12:24:24:04", "38:22:d6:87:fa:f0",
                "00:27:22:51:6e:e9", "dc:9f:db:1c:62:ba", "de:9f:db:1c:62:ba",
                "06:27:22:51:70:58", "06:27:22:b7:70:29", "00:27:22:b7:6d:32",
                "06:27:22:b7:6d:32" };
        mac = new String[] { "34:4b:50:ba:d7:73" };
        int[] signal_strength = { -58, -48, -50, -70, -58, -74, -73, -73, -74,
                -72, -83, -82, -74, -66, -84, -73, -77, -89, -91, -80, -78 };
        // init wifi data
        for (int i = 0; i < mac.length; i++) {
            WifiData wifidata1 = new WifiData();
            wifidata1.bssid = mac[i];
            wifidata1.level = signal_strength[i];
            listWifiData.add(wifidata1);
        }
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

         initgsmcelldata();
//         initcdmacelldata();
        initwifidata();
//        initwcdmacelldata();
        // for (int i = 0; i < 200; i ++) {
        HttpPost httppost = new HttpPost("http://loc.map.baidu.com/sdk.php");
        ArrayList<BasicNameValuePair> arraylist = new ArrayList<BasicNameValuePair>();
        arraylist.add(new BasicNameValuePair("bloc", getPostDataString()));
        try {
            UrlEncodedFormEntity urlencodedformentity = new UrlEncodedFormEntity(
                    arraylist, HTTP.UTF_8);
            httppost.setEntity(urlencodedformentity);
            DefaultHttpClient defaulthttpclient = new DefaultHttpClient();
            defaulthttpclient.getParams().setParameter(
                    "http.connection.timeout", Integer.valueOf(15000));
            defaulthttpclient.getParams().setParameter("http.socket.timeout",
                    Integer.valueOf(15000));
            HttpResponse httpresponse = defaulthttpclient.execute(httppost);
            int intHttpCode = httpresponse.getStatusLine().getStatusCode();
            if (intHttpCode == 200) {
                String strResult = EntityUtils.toString(
                        httpresponse.getEntity(), HTTP.UTF_8);
                System.out.println(strResult);
            } else {
                System.out.println("error http code = " + intHttpCode);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // }
    }

    private static String getPostDataString() {
        String strReturn = "";
        StringBuffer stringbuffer = new StringBuffer(1024);
        if (listCellData != null && listCellData.size() > 0) {
            String s1 = getCellDataString(listCellData.get(0).mcc,
                    listCellData.get(0).mnc, listCellData.get(0).lac,
                    listCellData.get(0).cid, 1000);
            if (s1 != null && s1.length() > 0) {
                stringbuffer.append(s1);
            }
        }
        if (listWifiData != null && listWifiData.size() > 0) {
            String s3 = getWifiDataString(listWifiData);
            if (s3 != null && s3.length() > 0)
                stringbuffer.append(s3);
        }
        if (stringbuffer.toString().length() <= 0) {
            return "";
        }
        stringbuffer.append("&addr=");
        stringbuffer
                .append("country|province|city|district|street|street_number");
        stringbuffer.append("&coor=");
        stringbuffer.append("gcj02");
        stringbuffer.append("&os=android&prod=");
        stringbuffer.append("default");
        if (strDeviceID != null && strDeviceID.length() > 0) {
            stringbuffer.append("&im=");
            stringbuffer.append(strDeviceID);
        }
        if (strModelNumber != null && strModelNumber.length() > 0) {
            stringbuffer.append("&mb=");
            stringbuffer.append(strModelNumber);
        }
        strReturn = (new StringBuilder())
                .append(BaiduEncode.encode(stringbuffer.toString()))
                .append("|tp=2").toString();
        System.out.println(strReturn);
        return strReturn;
    }

    private static String getCellDataString(int mcc, int mnc, int lac, int cid,
            int timeSpan) {
        StringBuffer stringbuffer = new StringBuffer(256);
        stringbuffer.append(String.format("&cl=%d|%d|%d|%d",
                new Object[] { Integer.valueOf(mcc), Integer.valueOf(mnc),
                        Integer.valueOf(lac), Integer.valueOf(cid) }));
        int i2 = 0;
        i2 = listCellData.size();
        if (i2 > 0) {
            stringbuffer.append("&clt=");
            for (int k2 = 0; k2 < i2; k2++) {
                // 双卡双待手机？
                CellData a1 = (CellData) listCellData.get(k2);
                if (k2 != i2 - 1) {
                    stringbuffer.append(String.format(
                            "%d|%d|%d|%d|%d;",
                            new Object[] { Integer.valueOf(a1.mcc),
                                    Integer.valueOf(a1.mnc),
                                    Integer.valueOf(a1.lac),
                                    Integer.valueOf(a1.cid),
                                    Long.valueOf(a1.time / 1000L) }));
                } else {
                    stringbuffer
                            .append(String.format(
                                    "%d|%d|%d|%d|%d;%d",
                                    new Object[] {
                                            Integer.valueOf(a1.mcc),
                                            Integer.valueOf(a1.mnc),
                                            Integer.valueOf(a1.lac),
                                            Integer.valueOf(a1.cid),
                                            Long.valueOf((System
                                                    .currentTimeMillis() - a1.time) / 1000L),
                                            Integer.valueOf(timeSpan / 1000) }));
                }
            }

        }
        return stringbuffer.toString();
    }

    private static String getWifiDataString(List<WifiData> list) {
        StringBuffer stringbuffer = new StringBuffer(256);
        int i1 = list.size();
        boolean flag = true;
        sortWifiData(list);
        if (i1 > 10) {
            // 最多10个wifi mac地址
            i1 = 10;
        }
        for (int j1 = 0; j1 < i1; j1++) {
            if (0 == ((WifiData) list.get(j1)).level) {
                continue;
            }
            if (flag) {
                flag = false;
                stringbuffer.append("&wf=");
                String s3 = ((WifiData) list.get(j1)).bssid;
                s3 = s3.replace(":", "");
                stringbuffer.append(s3);
                int k1 = ((WifiData) list.get(j1)).level;
                if (k1 < 0)
                    k1 = -k1;
                String s1 = String.format(";%d;",
                        new Object[] { Integer.valueOf(k1) });
                stringbuffer.append(s1);
                continue;
            }
            stringbuffer.append("|");
            String s4 = ((WifiData) list.get(j1)).bssid;
            s4 = s4.replace(":", "");
            stringbuffer.append(s4);
            int l1 = ((WifiData) list.get(j1)).level;
            if (l1 < 0) {
                // 负数变成正数
                l1 = -l1;
            }
            String s2 = String.format(";%d;",
                    new Object[] { Integer.valueOf(l1) });
            stringbuffer.append(s2);
        }

        return stringbuffer.toString();
    }

    /**
     * 按照信号强度排序
     */
    private static void sortWifiData(List<WifiData> list) {
        Object obj = null;
        boolean flag = true;
        int i1 = list.size();
        for (int j1 = i1 - 1; j1 >= 1 && flag; j1--) {
            flag = false;
            for (int k1 = 0; k1 < j1; k1++) {
                int l1 = ((WifiData) list.get(k1)).level;
                int i2 = ((WifiData) list.get(k1 + 1)).level;
                if (l1 < i2) {
                    WifiData scanresult = (WifiData) list.get(k1 + 1);
                    list.set(k1 + 1, list.get(k1));
                    list.set(k1, scanresult);
                    flag = true;
                }
            }

        }

    }

}
