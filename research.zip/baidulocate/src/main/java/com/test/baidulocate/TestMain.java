package com.test.baidulocate;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sankuai.locate.BaiduEncode;
import com.sankuai.locate.CellData;
import com.sankuai.locate.WifiData;
import com.test.baidulocate.bean.LocateReport;

public class TestMain {

    private static List<CellData> listCellData = new ArrayList<CellData>();

    private static List<WifiData> listWifiData = new ArrayList<WifiData>();

    private static String strDeviceID = "355921043431889";
    private static String strModelNumber = "Nexus S";

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        String perLine;
        final long time = System.currentTimeMillis();
        final String path = "/Users/chenhongbing/dev/workspace/baidulocate/src/main/java/";

        BufferedReader line = new BufferedReader(new InputStreamReader(
                new FileInputStream(path + "locatereport-2013-03-20_00011"),
                "UTF-8"));
        String strlineseparator = System.getProperty("line.separator");

        ThreadSafeClientConnManager connectionManager = new ThreadSafeClientConnManager();
        connectionManager.setDefaultMaxPerRoute(300);
        DefaultHttpClient defaulthttpclient = new DefaultHttpClient(
                connectionManager);
        defaulthttpclient.getParams().setParameter("http.connection.timeout",
                Integer.valueOf(15000));
        defaulthttpclient.getParams().setParameter("http.socket.timeout",
                Integer.valueOf(15000));

        while ((perLine = line.readLine()) != null) { // 已读去一行,信息保存在perLine中
            String jsondata = perLine.substring(54);

            try {
                LocateReport reportBean = JSON.parseObject(jsondata,
                        LocateReport.class);
                listWifiData = reportBean.getWifiData();
                listCellData = reportBean.getCellData();
                if (listCellData.size() > 0
                        && (listCellData.get(0).cid <= 0 || listCellData.get(0).lac <= 0)) {
                    continue;
                }
                HttpPost httppost = new HttpPost(
                        "http://loc.map.baidu.com/sdk.php");
                ArrayList<BasicNameValuePair> arraylist = new ArrayList<BasicNameValuePair>();
                arraylist.add(new BasicNameValuePair("bloc",
                        getPostDataString()));

                UrlEncodedFormEntity urlencodedformentity = new UrlEncodedFormEntity(
                        arraylist, HTTP.UTF_8);
                httppost.setEntity(urlencodedformentity);

                HttpResponse httpresponse = defaulthttpclient.execute(httppost);
                int intHttpCode = httpresponse.getStatusLine().getStatusCode();
                if (intHttpCode == 200) {
                    String strResult = EntityUtils.toString(
                            httpresponse.getEntity(), HTTP.UTF_8);
                    httpresponse.getEntity().consumeContent();
                    JSONObject jsonObject = JSONObject.parseObject(strResult);
                    JSONObject contentJSON = jsonObject
                            .getJSONObject("content");
                    JSONObject resultJSON = jsonObject.getJSONObject("result");
                    String error = resultJSON.getString("error");
                    if (!"161".equals(error)) {
                        // System.out.println("======== not 161 begin ========");
                        // System.out.println(perLine);
                        // System.out.println("======== not 161 end ========");
                        FileWriter fw = new FileWriter(path + "result_0_0_"
                                + time, true);
                        fw.write(perLine);
                        fw.write(strlineseparator);
                        fw.flush();
                        fw.close();
                        continue;
                    }
                    double radius = contentJSON.getDouble("radius");
                    JSONObject pointJSON = contentJSON.getJSONObject("point");
                    double lng1 = pointJSON.getDouble("x");
                    double lat1 = pointJSON.getDouble("y");
                    if (!reportBean.isEquals(lat1, lng1)) {
                        // System.out.println("======= not Equals=========");
                        // System.out.println(perLine);
                        // System.out.println(strResult);
                        // System.out.println("======= not Equals=========");
                        write(path, time, perLine, strlineseparator);
                    } else {
                        // System.out.println("ok");
                    }
                } else {
                    FileWriter fw = new FileWriter(path + "result_error_"
                            + time, true);
                    fw.write(perLine);
                    fw.write(strlineseparator);
                    fw.flush();
                    fw.close();
                    // System.out.println("error http code = " + intHttpCode);
                }
            } catch (Exception ex) {
                // write(perLine, strlineseparator);
                FileWriter fw = new FileWriter(path + "result_error_" + time,
                        true);
                fw.write(perLine);
                fw.write(strlineseparator);
                fw.flush();
                fw.close();
            }
        }
    }

    private static void write(String path, long time, String perLine,
            String strlineseparator) throws Exception {
        FileWriter fw = new FileWriter(path + "result_notEquals_" + time, true);
        fw.write(perLine);
        fw.write(strlineseparator);
        fw.flush();
        fw.close();
    }

    private static String getPostDataString() {
        String strReturn = "";
        StringBuffer stringbuffer = new StringBuffer(1024);
        if (listCellData != null && listCellData.size() > 0) {
            String s1 = getCellDataString(listCellData.get(0).mcc,
                    listCellData.get(0).mnc, listCellData.get(0).lac,
                    listCellData.get(0).cid, 1000);
            if (s1 != null && s1.length() > 0) {
                stringbuffer.append(s1);
            }
        }
        if (listWifiData != null && listWifiData.size() > 0) {
            String s3 = getWifiDataString(listWifiData);
            if (s3 != null && s3.length() > 0)
                stringbuffer.append(s3);
        }
        if (stringbuffer.toString().length() <= 0) {
            return "";
        }
        stringbuffer.append("&addr=");
        stringbuffer
                .append("country|province|city|district|street|street_number");
        stringbuffer.append("&coor=");
        stringbuffer.append("gcj02");
        stringbuffer.append("&os=android&prod=");
        stringbuffer.append("default");
        if (strDeviceID != null && strDeviceID.length() > 0) {
            stringbuffer.append("&im=");
            stringbuffer.append(strDeviceID);
        }
        if (strModelNumber != null && strModelNumber.length() > 0) {
            stringbuffer.append("&mb=");
            stringbuffer.append(strModelNumber);
        }
        strReturn = (new StringBuilder())
                .append(BaiduEncode.encode(stringbuffer.toString()))
                .append("|tp=2").toString();
        return strReturn;
    }

    private static String getCellDataString(int mcc, int mnc, int lac, int cid,
            int timeSpan) {
        StringBuffer stringbuffer = new StringBuffer(256);
        stringbuffer.append(String.format("&cl=%d|%d|%d|%d",
                new Object[] { Integer.valueOf(mcc), Integer.valueOf(mnc),
                        Integer.valueOf(lac), Integer.valueOf(cid) }));
        int i2 = 0;
        i2 = listCellData.size();
        if (i2 > 0) {
            stringbuffer.append("&clt=");
            for (int k2 = 0; k2 < i2; k2++) {
                // 双卡双待手机？
                CellData a1 = (CellData) listCellData.get(k2);
                if (k2 != i2 - 1) {
                    stringbuffer.append(String.format(
                            "%d|%d|%d|%d|%d;",
                            new Object[] { Integer.valueOf(a1.mcc),
                                    Integer.valueOf(a1.mnc),
                                    Integer.valueOf(a1.lac),
                                    Integer.valueOf(a1.cid),
                                    Long.valueOf(a1.time / 1000L) }));
                } else {
                    stringbuffer
                            .append(String.format(
                                    "%d|%d|%d|%d|%d;%d",
                                    new Object[] {
                                            Integer.valueOf(a1.mcc),
                                            Integer.valueOf(a1.mnc),
                                            Integer.valueOf(a1.lac),
                                            Integer.valueOf(a1.cid),
                                            Long.valueOf((System
                                                    .currentTimeMillis() - a1.time) / 1000L),
                                            Integer.valueOf(timeSpan / 1000) }));
                }
            }

        }
        return stringbuffer.toString();
    }

    private static String getWifiDataString(List<WifiData> list) {
        StringBuffer stringbuffer = new StringBuffer(256);
        int i1 = list.size();
        boolean flag = true;
        sortWifiData(list);
        if (i1 > 10) {
            // 最多10个wifi mac地址
            i1 = 10;
        }
        for (int j1 = 0; j1 < i1; j1++) {
            if (0 == ((WifiData) list.get(j1)).level) {
                continue;
            }
            if (flag) {
                flag = false;
                stringbuffer.append("&wf=");
                String s3 = ((WifiData) list.get(j1)).bssid;
                s3 = s3.replace(":", "");
                stringbuffer.append(s3);
                int k1 = ((WifiData) list.get(j1)).level;
                if (k1 < 0)
                    k1 = -k1;
                String s1 = String.format(";%d;",
                        new Object[] { Integer.valueOf(k1) });
                stringbuffer.append(s1);
                continue;
            }
            stringbuffer.append("|");
            String s4 = ((WifiData) list.get(j1)).bssid;
            s4 = s4.replace(":", "");
            stringbuffer.append(s4);
            int l1 = ((WifiData) list.get(j1)).level;
            if (l1 < 0) {
                // 负数变成正数
                l1 = -l1;
            }
            String s2 = String.format(";%d;",
                    new Object[] { Integer.valueOf(l1) });
            stringbuffer.append(s2);
        }

        return stringbuffer.toString();
    }

    /**
     * 按照信号强度排序
     */
    private static void sortWifiData(List<WifiData> list) {
        Object obj = null;
        boolean flag = true;
        int i1 = list.size();
        for (int j1 = i1 - 1; j1 >= 1 && flag; j1--) {
            flag = false;
            for (int k1 = 0; k1 < j1; k1++) {
                int l1 = ((WifiData) list.get(k1)).level;
                int i2 = ((WifiData) list.get(k1 + 1)).level;
                if (l1 < i2) {
                    WifiData scanresult = (WifiData) list.get(k1 + 1);
                    list.set(k1 + 1, list.get(k1));
                    list.set(k1, scanresult);
                    flag = true;
                }
            }

        }

    }

}
