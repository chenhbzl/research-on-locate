package com.sankuai.locate;

public class WifiData {
    public String bssid;
    public int level;
}
