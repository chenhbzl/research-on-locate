package com.test.celllocate;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.test.celllocate.interfaces.LocationCallback;

public class Test extends Activity {

    private Button btnGetInfo = null;
    private final static String URL = "http://st.map.soso.com/api?size=%d*%d";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        btnGetInfo = (Button) findViewById(R.id.btnGet);
        btnGetInfo.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                locate(Test.this);
            }
        });

    }

    private String getImageMapUrl() {
        DisplayMetrics metric = new DisplayMetrics();
        metric = getResources().getDisplayMetrics();

        int btnHeight = (int) (btnGetInfo.getHeight() * metric.density);
        Log.d("", "btnHeight = " + btnHeight);
        int width = (int) (metric.widthPixels);
        int height = (int) (metric.heightPixels - 100 - btnHeight);
        Object[] obj = { 220, 380 };

        return String.format(URL, obj) + "&center=%f,%f&zoom=16&markers=%f,%f";
    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        // mHandler.sendEmptyMessageDelayed(0, 1000);
    }

    // Handler mHandler = new Handler() {
    // @Override
    // public void handleMessage(Message msg) {
    // switch (msg.what) {
    // case 0:
    // locate(Test.this);
    // break;
    // default:
    // break;
    // }
    // }
    // };

    private void locate(Context context) {

        TextView tv = (TextView) Test.this.findViewById(R.id.textView1);
        tv.setText("定位中....");
        TestMainGoogleLocate.getLocate(context, sCallback1, getImageMapUrl());

    }

    private LocationCallback sCallback1 = new LocationCallback() {

        @Override
        public void Error(String msg) {
            System.out.println("ERROR: " + msg);
            TextView tv = (TextView) Test.this.findViewById(R.id.textView1);
            tv.setText("定位失败啦  " + msg);
        }

        @Override
        public void getMap(Bitmap bitmap) {
            ImageView iv = (ImageView) Test.this.findViewById(R.id.imageview1);
            if (bitmap != null) {
                iv.setImageBitmap(bitmap);
            } else {
                iv.setImageResource(R.drawable.icon);
            }
        }

        @Override
        public void getLocation(String location) {
            TextView tv = (TextView) Test.this.findViewById(R.id.textView1);
            if (location != null) {
                tv.setText(location);
            } else {
                tv.setText("定位失败啦");
            }
        }
    };

}