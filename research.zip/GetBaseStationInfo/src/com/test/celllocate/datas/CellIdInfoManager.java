package com.test.celllocate.datas;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Build;
import android.telephony.NeighboringCellInfo;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;

import com.test.celllocate.bean.CellData;

/**
 * 
 * @author chenhongbing
 * 
 */
public class CellIdInfoManager {

    private Context context;

    public CellIdInfoManager(Context context) {
        this.context = context;
    }

    public List<CellData> getCellInfo() {
        List<CellData> listInfo = new ArrayList<CellData>();

        int countryCode = 460;
        int networkCode = 0;
        int signalStrength = (int) (-50 * Math.random() - 50); // 定位和它关系不大
        CellData info = new CellData();

        TelephonyManager manager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        if (manager.getCellLocation() instanceof GsmCellLocation) {
            GsmCellLocation gsm = (GsmCellLocation) manager.getCellLocation();
            if (gsm == null) {
                return listInfo;
            }
            if (manager.getNetworkOperator() == null
                    || manager.getNetworkOperator().length() == 0) {
                return listInfo;
            }
            try {
                countryCode = Integer.parseInt(manager.getNetworkOperator()
                        .substring(0, 3));
                networkCode = Integer.parseInt(manager.getNetworkOperator()
                        .substring(3, 5));
            } catch (Exception ex) {
                countryCode = 460;
                int networkType = manager.getNetworkType();
                if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                        || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                    networkCode = 0;
                } else {
                    networkCode = 1;
                }
            }

            String radioType = "";
            int networkType = manager.getNetworkType();
            if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                    || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                radioType = "gsm";
            } else {
                radioType = "wcdma";
            }
            info.cid = gsm.getCid();
            info.mcc = countryCode;
            info.mnc = networkCode;
            info.lac = gsm.getLac();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
                info.psc = gsm.getPsc();
            }
            info.radioType = radioType;
            info.signalStrength = signalStrength;
            info.time = System.currentTimeMillis();

            listInfo.add(info);

            List<NeighboringCellInfo> list = manager.getNeighboringCellInfo();
            for (NeighboringCellInfo i : list) {
                CellData ci = new CellData();
                ci.cid = i.getCid();
                ci.mcc = countryCode;
                ci.mnc = networkCode;
                ci.lac = i.getLac();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
                    ci.psc = i.getPsc();
                }
                ci.radioType = radioType;
                ci.signalStrength = 2 * i.getRssi() - 113;
                ci.time = System.currentTimeMillis();
                listInfo.add(ci);
            }
        } else if (manager.getCellLocation() instanceof CdmaCellLocation) {
            CdmaCellLocation cdma = (CdmaCellLocation) manager
                    .getCellLocation();
            if (cdma == null) {
                return listInfo;
            }
            if (manager.getNetworkOperator() == null
                    || manager.getNetworkOperator().length() == 0) {
                return listInfo;
            }
            try {
                countryCode = Integer.parseInt(manager.getNetworkOperator());
            } catch (Exception ex) {
                countryCode = 460;
            }
            info.cid = cdma.getBaseStationId();
            info.mcc = countryCode;
            info.mnc = cdma.getSystemId();
            info.lac = cdma.getNetworkId();
            info.radioType = "cdma";
            info.time = System.currentTimeMillis();
            listInfo.add(info);
        }
        return listInfo;
    }
}