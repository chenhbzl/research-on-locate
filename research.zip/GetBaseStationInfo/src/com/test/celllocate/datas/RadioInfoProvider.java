package com.test.celllocate.datas;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.telephony.CellLocation;
import android.telephony.NeighboringCellInfo;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;

public class RadioInfoProvider {

    private final TelephonyManager mTeleManager;

    public RadioInfoProvider(Context context) {
        mTeleManager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
    }

    public boolean addCellInfo(JSONObject holder) throws JSONException {
        TelephonyManager manager = mTeleManager;
        CellLocation cellLocation = manager.getCellLocation();
        if (cellLocation == null) {
            return false;
        }
        int mcc = 460;
        int mnc = 0;
        int signalStrength = (int) (-50 * Math.random() - 50); // 定位和它关系不大
        if (manager.getCellLocation() instanceof GsmCellLocation) {
            try {
                mcc = Integer.parseInt(manager.getNetworkOperator().substring(
                        0, 3));
                mnc = Integer.parseInt(manager.getNetworkOperator().substring(
                        3, 5));
            } catch (Exception ex) {
                mcc = 460;
                int networkType = manager.getNetworkType();
                if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                        || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                    // 中国移动
                    mnc = 0;
                } else {
                    // 中国联通
                    mnc = 1;
                }
            }
        } else if (manager.getCellLocation() instanceof CdmaCellLocation) {
            // 中国电信
            mnc = 3;
        }
        holder.put("home_mobile_country_code", mcc);
        holder.put("home_mobile_network_code", mnc);
        if (mcc == 460) {
            holder.put("address_language", "zh_CN");
        } else {
            holder.put("address_language", "en_US");
        }
        JSONArray cellArray = new JSONArray();
        JSONObject primaryRadioData = new JSONObject();
        if (cellLocation instanceof GsmCellLocation) {
            GsmCellLocation gsmCellLocation = ((GsmCellLocation) cellLocation);
            primaryRadioData.put("cell_id", gsmCellLocation.getCid());
            primaryRadioData
                    .put("location_area_code", gsmCellLocation.getLac());
            primaryRadioData.put("mobile_country_code", mcc);
            primaryRadioData.put("mobile_network_code", mnc);
            primaryRadioData.put("signal_strength", signalStrength);
            cellArray.put(primaryRadioData);
            int networkType = mTeleManager.getNetworkType();
            if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                    || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                List<NeighboringCellInfo> cellInfoList = mTeleManager
                        .getNeighboringCellInfo();
                if (cellInfoList != null) {
                    for (NeighboringCellInfo cell : cellInfoList) {
                        JSONObject data = new JSONObject();
                        data.put("cell_id", cell.getCid());
                        data.put("location_area_code", cell.getLac());
                        data.put("mobile_country_code", mcc);
                        data.put("mobile_network_code", mnc);
                        data.put("age", 0);
                        data.put("signal_strength", 2 * cell.getRssi() - 113);
                        cellArray.put(data);
                    }
                }
                holder.put("radio_type", "gsm");
            } else {
                holder.put("radio_type", "wcdma");
            }
        } else if (cellLocation instanceof CdmaCellLocation) {
            CdmaCellLocation cdmaCellLocation = ((CdmaCellLocation) cellLocation);
            primaryRadioData
                    .put("cell_id", cdmaCellLocation.getBaseStationId());
            primaryRadioData.put("location_area_code",
                    cdmaCellLocation.getNetworkId());
            primaryRadioData.put("mobile_country_code", mcc);
            primaryRadioData.put("mobile_network_code",
                    cdmaCellLocation.getSystemId());
            primaryRadioData.put("signal_strength", signalStrength);
            cellArray.put(primaryRadioData);
            holder.put("radio_type", "cdma");
        }
        if (cellArray.length() > 0) {
            holder.put("cell_towers", cellArray);
            return true;
        } else {
            return false;
        }
    }

    public String getLacCellId() {
        int cellid = 0;
        int lac = 0;
        TelephonyManager manager = mTeleManager;
        CellLocation cellLocation = manager.getCellLocation();
        if (cellLocation instanceof GsmCellLocation) {
            GsmCellLocation gsmCellLocation = ((GsmCellLocation) cellLocation);
            cellid = gsmCellLocation.getCid();
            lac = gsmCellLocation.getLac();
            int networkType = mTeleManager.getNetworkType();
            if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                    || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                List<NeighboringCellInfo> cellInfoList = mTeleManager
                        .getNeighboringCellInfo();
                if (cellInfoList != null) {
                    for (NeighboringCellInfo cell : cellInfoList) {
                        cellid = cell.getCid();
                        lac = cell.getLac();
                    }
                }
            }
        } else if (cellLocation instanceof CdmaCellLocation) {
            CdmaCellLocation cdmaCellLocation = ((CdmaCellLocation) cellLocation);
            cellid = cdmaCellLocation.getBaseStationId();
            lac = cdmaCellLocation.getNetworkId();
        }
        return lac + "," + cellid;
    }
}
