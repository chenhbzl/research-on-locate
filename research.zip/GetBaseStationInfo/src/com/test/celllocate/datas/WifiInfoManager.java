package com.test.celllocate.datas;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;

import com.test.celllocate.bean.WifiData;

public class WifiInfoManager {

    private Context context;

    public WifiInfoManager(Context context) {
        super();
        this.context = context;
    }

    public List<WifiData> getWifiInfo() {
        List<WifiData> listInfo = new ArrayList<WifiData>();
        WifiManager wifiManager = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        List<ScanResult> scanResults = wifiManager.getScanResults();
        if (scanResults == null || scanResults.isEmpty()) {
            return listInfo;
        }
        for (int i = 0, n = scanResults.size(); i < n; i++) {
            ScanResult scanResult = scanResults.get(i);
            if (null != scanResult.BSSID) {
                WifiData data = new WifiData();
                data.bssid = scanResult.BSSID;
                data.level = scanResult.level;
                listInfo.add(data);
            }
        }

        return listInfo;
    }
}
