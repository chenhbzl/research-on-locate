package com.test.celllocate.datas;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;

public class WifiInfoProvider {

    private final WifiManager mWifiManager;

    public WifiInfoProvider(Context context) {
        mWifiManager = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
    }

    public boolean addWifiInfo(JSONObject holder) throws JSONException {
        List<ScanResult> scanResults = mWifiManager.getScanResults();
        if (scanResults == null || scanResults.isEmpty()) {
            return false;
        }
        JSONArray wifiArray = new JSONArray();
        for (int i = 0, n = scanResults.size(); i < n; i++) {
            ScanResult scanResult = scanResults.get(i);
            if (null != scanResult.BSSID) {
                JSONObject data = new JSONObject();
                data.put("mac_address", scanResult.BSSID);
                data.put("signal_strength", scanResult.level);
                data.put("ssid", scanResult.SSID);
                wifiArray.put(data);
            }
        }
        holder.put("wifi_towers", wifiArray);
        return true;
    }

    public String getFirstBSSID() {
        String strBSSID = "";
        List<ScanResult> scanResults = mWifiManager.getScanResults();
        if (scanResults == null || scanResults.isEmpty()) {
            return strBSSID;
        }
        for (int i = 0, n = scanResults.size(); i < n; i++) {
            ScanResult scanResult = scanResults.get(i);
            if (null != scanResult.BSSID) {
                strBSSID = scanResult.BSSID;
                break;
            }
        }
        return strBSSID;
    }
}
