package com.test.celllocate.datas;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.test.celllocate.utils.ApnSetUtils;
import com.test.celllocate.utils.UniqueDeviceId;

public class LocationInfoReporter {
    public static final String LOCATION_REPORT_URL = "http://api.mobile.meituan.com/locate/v1/location/report";
    public static final long DELAYTIME = 3 * 1000;

    private RadioInfoProvider mRadioInfoProvider;
    private WifiInfoProvider mWifiInfoProvider;
    private String mUrl;
    private Context mContext;

    public LocationInfoReporter(Context context) {
        mContext = context;
        mRadioInfoProvider = new RadioInfoProvider(context);
        mWifiInfoProvider = new WifiInfoProvider(context);
        mUrl = LOCATION_REPORT_URL + "?appname=getbasestationinfo&did="
                + UniqueDeviceId.getDeviceId(context);
    }

    public void reportLocationInfo(final String response) {

        try {
            Log.d("", "LocationInfoReporter response: " + response);
            JSONObject requestJSON = new JSONObject();
            requestJSON.put("version", "1.1.0");
            requestJSON.put("request_address", true);
            boolean hasRadioInfo = mRadioInfoProvider.addCellInfo(requestJSON);
            boolean hasWifiInfo = mWifiInfoProvider.addWifiInfo(requestJSON);
            if (hasRadioInfo || hasWifiInfo) {
                Log.d("", "LocationInfoReporter request:" + requestJSON);
                JSONObject holder = new JSONObject();
                holder.put("source", "google");
                holder.put("request", requestJSON);
                holder.put("response", response);
                LocateReportAsyncTask task = new LocateReportAsyncTask();
                task.execute(holder.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class LocateReportAsyncTask extends
            AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... params) {
            String strResult = null;
            try {
                HttpPost httppost = new HttpPost(mUrl);
                Log.e("", "report url = " + mUrl);
                StringEntity se = new StringEntity(params[0], HTTP.UTF_8);
                httppost.setEntity(se);
                DefaultHttpClient defaulthttpclient = new DefaultHttpClient();
                defaulthttpclient.getParams().setParameter(
                        "http.connection.timeout", Integer.valueOf(15000));
                defaulthttpclient.getParams().setParameter(
                        "http.socket.timeout", Integer.valueOf(15000));
                ApnSetUtils.setAPN(mContext, defaulthttpclient);
                HttpResponse httpresponse = defaulthttpclient.execute(httppost);
                int intHttpCode = httpresponse.getStatusLine().getStatusCode();
                if (intHttpCode == 200) {
                    strResult = EntityUtils.toString(httpresponse.getEntity(),
                            HTTP.UTF_8);
                    Log.d("", "report locate result : " + strResult);
                } else {
                    Log.d("", "error http code = " + intHttpCode);
                }
                httpresponse.getEntity().consumeContent();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return strResult;
        }

        @Override
        protected void onPostExecute(String result) {

        }
    }
}
