package com.test.celllocate.bean;

public class WifiData {
    public String bssid;
    public int level;
}
