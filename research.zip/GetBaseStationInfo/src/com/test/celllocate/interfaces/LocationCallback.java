package com.test.celllocate.interfaces;

import android.graphics.Bitmap;

public interface LocationCallback {

    void getLocation(String location);
    
    void getMap(Bitmap bitmap);

    void Error(String msg);
}
