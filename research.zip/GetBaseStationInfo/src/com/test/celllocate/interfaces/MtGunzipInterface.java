package com.test.celllocate.interfaces;

import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

import com.google.common.io.Gunzipper.GunzipInterface;

public class MtGunzipInterface implements GunzipInterface {

    public InputStream gunzip(InputStream inputstream) throws IOException {
        return new GZIPInputStream(inputstream);
    }

}
