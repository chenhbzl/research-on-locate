package com.test.celllocate.utils;

import android.text.TextUtils;

public final class APNMatchTools {

    public static class APNNet {
        /**
         * 中国电信ctwap
         */
        public static final String CTWAP = "ctwap";

        /**
         * 中国电信ctnet
         */
        public static final String CTNET = "ctnet";
        /**
         * 中国移动cmwap
         */
        public static final String CMWAP = "cmwap";

        /**
         * 中国移动cmnet
         */
        public static final String CMNET = "cmnet";

        /**
         * 中国联通3G因特网设置
         */

        public static final String CMTDS = "cmtds";

        /**
         * 3G wap 中国联通3gwap APN
         */
        public static final String GWAP_3 = "3gwap";

        /**
         * 3G net 中国联通3gnet APN
         */
        public static final String GNET_3 = "3gnet";

        /**
         * uni wap 中国联通uni wap APN
         */
        public static final String UNIWAP = "uniwap";
        /**
         * uni net 中国联通uni net APN
         */
        public static final String UNINET = "uninet";
    }

    public static String matchAPN(final String oldCurrentName) {
        String currentName = oldCurrentName;
        if (TextUtils.isEmpty((currentName))) {
            return "";
        }
        currentName = currentName.toLowerCase();
        if (currentName.startsWith(APNNet.CMNET)) {
            return APNNet.CMNET;
        } else if (currentName.startsWith(APNNet.CMWAP)) {
            return APNNet.CMWAP;
        } else if (currentName.startsWith(APNNet.CTNET)) {
            return APNNet.CTNET;
        } else if (currentName.startsWith(APNNet.CTWAP)) {
            return APNNet.CTWAP;
        } else if (currentName.startsWith(APNNet.GNET_3)) {
            return APNNet.GNET_3;
        } else if (currentName.startsWith(APNNet.GWAP_3)) {
            return APNNet.GWAP_3;
        } else if (currentName.startsWith(APNNet.UNINET)) {
            return APNNet.UNINET;
        } else if (currentName.startsWith(APNNet.UNIWAP)) {
            return APNNet.UNIWAP;
        } else if (currentName.startsWith(APNNet.CMTDS)) {
            return APNNet.CMTDS;
        } else if (currentName.startsWith("default")) {
            return "default";
        } else {
            return "";
        }
    }
}
