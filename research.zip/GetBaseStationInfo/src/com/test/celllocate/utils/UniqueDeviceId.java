package com.test.celllocate.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

/**
 * Created by IntelliJ IDEA. User: liang Date: 11-6-21 Time: 下午4:58 To change
 * this template use File | Settings | File Templates.
 */
public class UniqueDeviceId {

    /**
     * Get IMEI, if can't get IMEI, generate a fake imei, 15 digital unique
     * device id;
     * 
     * @return String
     */
    public static String getDeviceId(Context context) {
        try {
            // 1 compute IMEI
            TelephonyManager TelephonyMgr = (TelephonyManager) context
                    .getSystemService(Context.TELEPHONY_SERVICE);

            String imei = null;
            if (TelephonyMgr != null) {
                imei = TelephonyMgr.getDeviceId(); // Requires READ_PHONE_STATE
            }
            if (!TextUtils.isEmpty(imei)) {
                // got imei, return it
                return imei;
            }
            imei = null;
            // 2 compute DEVICE ID
            String devIDShort = "35"
                    + // we make this look like a valid IMEI
                    Build.BOARD.length() % 10 + Build.BRAND.length() % 10
                    + Build.CPU_ABI.length() % 10 + Build.DEVICE.length() % 10
                    + Build.DISPLAY.length() % 10 + Build.HOST.length() % 10
                    + Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10
                    + Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10
                    + Build.TAGS.length() % 10 + Build.TYPE.length() % 10
                    + Build.USER.length() % 10; // 13 digits

            // 3 android ID - unreliable
            String androidId = Settings.Secure.getString(
                    context.getContentResolver(), Settings.Secure.ANDROID_ID);

            // 4 wifi manager read MAC address - requires
            // android.permission.ACCESS_WIFI_STATE or comes as null
            WifiManager wm = (WifiManager) context
                    .getSystemService(Context.WIFI_SERVICE);
            String wlanMac = null;
            if (wm != null) {
                try {
                    wlanMac = wm.getConnectionInfo().getMacAddress();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            // 5 Bluetooth MAC address android.permission.BLUETOOTH required, so
            // currenty just comment out, in case we use this method later
            String btMac = null;

            /*
             * BluetoothAdapter bluetoothAdapter = null; // Local Bluetooth
             * adapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
             * if (bluetoothAdapter != null) { try { btMac =
             * bluetoothAdapter.getAddress(); } catch (Exception e) {
             * e.printStackTrace(); } }
             */

            // 6 SUM THE IDs
            String devIdLong = imei + devIDShort + androidId + wlanMac + btMac;
            MessageDigest m = null;
            try {
                m = MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            m.update(devIdLong.getBytes(), 0, devIdLong.length());
            byte md5Data[] = m.digest();

            String uniqueId = "";
            for (int i = 0, len = md5Data.length; i < len; i++) {
                int b = (0xFF & md5Data[i]);
                // if it is a single digit, make sure it have 0 in front (proper
                // padding)
                if (b <= 0xF)
                    uniqueId += "0";
                // add number to string
                uniqueId += Integer.toHexString(b);
            }
            uniqueId = uniqueId.toUpperCase();
            if (uniqueId.length() > 15) {
                uniqueId = uniqueId.substring(0, 15);
            }
            return uniqueId;
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return "DeviceId0";
    }

}
