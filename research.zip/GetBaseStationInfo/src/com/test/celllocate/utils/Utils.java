package com.test.celllocate.utils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 工具类
 * 
 * @author mashengchao 11-02-14
 */
public class Utils {
    private static final long MIN_DATA_BLOCK_SIZE = 3 * 1024 * 1024;
    public static final String LONG_DATE_FORMAT = "yyyy-MM-dd HH:mm";
    public static final String SHORT_DATE_FORMAT = "HH:mm";

    public static HashMap<String, String> getConfig() {
        return null;
    }

    /**
     * 获取当前版本信息
     * 
     * @param context
     * @return
     */
    public static PackageInfo getCurrentVersion(Context context) {
        PackageInfo pInfo = null;
        try {
            pInfo = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), 0);
        } catch (Exception e) {
            
        }

        return pInfo;
    }

    public static Object getMetaDate(Context context, String key) {
        Object value = null;
        try {
            ApplicationInfo appi = context.getPackageManager()
                    .getApplicationInfo(context.getPackageName(),
                            PackageManager.GET_META_DATA);

            Bundle bundle = appi.metaData;

            value = bundle.get(key);

        } catch (NameNotFoundException e) {
            
        } catch (Exception e) {
            
        }

        return value == null ? "" : value;
    }

    /**
     * 递归删除父控件中包含的所有的子元素。
     * 
     * @param parent
     *            父控件
     */
    public static void deleteChildView(View parent) {
        if (parent instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) parent;
            int count = vg.getChildCount();
            if (count > 0) {
                for (int i = 0; i < count; i++) {
                    View child = vg.getChildAt(i);
                    deleteChildView(child);
                }
            }
            try {
                vg.removeAllViews();
            } catch (Exception ex) {
                // 此处必须加cache，因为ListView不能removeAllViews。
                if (parent instanceof ListView) {
                    ((ListView) parent).setAdapter(null);
                }
            }
        }
    }

    public static String getCurrentAPN(Context context) {
        String currentAPN = "";
        try {
            ConnectivityManager conManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = conManager
                    .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            currentAPN = info.getExtraInfo();
        } catch (Exception e) {
            
        }

        return null == currentAPN ? "" : currentAPN;
    }

    // 获取机器码
    public static String getDeviceId(Context context) {
        TelephonyManager tm = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);

        return tm.getDeviceId();// 获取机器码
    }

    public static boolean hasSdcard() {
        boolean hasSdcard = false;
        String storageState = Environment.getExternalStorageState();

        if (storageState.equals(Environment.MEDIA_MOUNTED)) {
            hasSdcard = true;
        }

        return hasSdcard;
    }

    public static boolean isSdcardFull() {
        boolean isSdcardFull = true;
        String storageState = Environment.getExternalStorageState();

        if (storageState.equals(Environment.MEDIA_MOUNTED)) {
            isSdcardFull = checkFull(Environment.getExternalStorageDirectory()
                    .getAbsolutePath());
        }

        return isSdcardFull;
    }

    public static boolean isDataFull() {
        boolean isDataFileFull = true;
        try {
            isDataFileFull = checkFull(Environment.getDataDirectory()
                    .getAbsolutePath());
        } catch (Throwable t) {
            
        }

        return isDataFileFull;
    }

    private static boolean checkFull(String strPath) {
        boolean isFull = false;

        try {
            // 取得/data文件路径
            StatFs statfs = new StatFs(strPath);
            // 获取block的SIZE
            long blocSize = statfs.getBlockSize();
            // 获取能被程序使用的block数
            long availaBlock = statfs.getAvailableBlocks();
            long size = blocSize * availaBlock;
            Log.d("","/data directory size is " + size);
            if (size < MIN_DATA_BLOCK_SIZE) {
                Log.d("","data is full!!");
                isFull = true;
            }
        } catch (Throwable t) {
            
        }
        return isFull;
    }

    public static boolean isNetworkWifi(Context context) {
        boolean res = false;
        if (context == null) {
            return false;
        }

        NetworkInfo ni = null;
        try {
            ni = ((ConnectivityManager) context
                    .getSystemService("connectivity")).getActiveNetworkInfo();
        } catch (Exception e) {
            return false;
        }
        // 1 == WIFI, 0 == MOBILE
        return ((ni != null) && (ni.getType() == 1));
    }

    /**
     * 是否调整上网，即：非２G
     * 
     * @param context
     * @return
     */
    public static boolean isHighspeedInternet(Context context) {
        if (Utils.isNetworkWifi(context)) {
            return true;
        } else {
            String currentApn = Utils.getCurrentAPN(context);
            // ３G状态下
            if (currentApn.equals(APNMatchTools.APNNet.GNET_3)
                    || currentApn.equals(APNMatchTools.APNNet.GWAP_3)
                    || currentApn.equals(APNMatchTools.APNNet.CMTDS)) {
                return true;
            }
        }

        return false;
    }

    private static void delete(File file) {
        if (file.isFile()) {
            file.delete();
            return;
        }

        if (file.isDirectory()) {
            File[] childFiles = file.listFiles();
            if (childFiles == null || childFiles.length == 0) {
                file.delete();
                return;
            }

            for (int i = 0; i < childFiles.length; i++) {
                delete(childFiles[i]);
            }
            file.delete();
        }
    }

    /**
     * @param context
     * 
     * @return 缓存大小
     * 
     * @author leidiqiu update @ 2011-12-6 10:58:28
     */
    public static int getCacheSize(Context context) {
        int size = 0;
        String externalCacheDir = String.format("/Android/data/%s/cache/",
                context.getPackageName());
        File sdcardDir = new File(Environment.getExternalStorageDirectory()
                .getAbsolutePath() + externalCacheDir);
        File[] sdcardFiles = sdcardDir.listFiles();
        if (sdcardFiles != null) {
            for (File file : sdcardFiles) {
                if (!file.isDirectory()) {
                    size += file.length();
                }
            }
        }

        File cacheDir = context.getCacheDir();
        File[] cacheFiles = cacheDir.listFiles();
        if (cacheFiles != null) {
            for (File file : cacheFiles) {
                if (!file.isDirectory()) {
                    size += file.length();
                }
            }
        }
        return size;
    }

    /**
     * 清空data
     * 
     * @param context
     *            上下文
     * @return 是否正常清理
     */
    public static boolean clearData(Context context) {
        File dataDir = new File(context.getApplicationInfo().dataDir);
        File[] dataFiles = dataDir.listFiles();
        if (dataFiles != null) {
            for (File file : dataFiles) {
                if (!file.isDirectory()) {
                    delete(file);
                } else {
                    File[] dataSubFiles = file.listFiles();
                    for (File subFile : dataSubFiles) {
                        if (!subFile.isDirectory()) {
                            delete(subFile);
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * 清空cache
     * 
     * @param context
     *            上下文
     * @return 是否正常清理
     */
    public static boolean clearCache(Context context) {
        String externalCacheDir = String.format("/Android/data/%s/cache/",
                context.getPackageName());
        File sdcardDir = new File(Environment.getExternalStorageDirectory()
                .getAbsolutePath() + externalCacheDir);
        File[] sdcardFiles = sdcardDir.listFiles();
        if (sdcardFiles != null) {
            for (File file : sdcardFiles) {
                if (!file.isDirectory()) {
                    file.delete();
                } else {
                    delete(file);
                }
            }
        }

        File cacheDir = context.getCacheDir();
        File[] cacheFiles = cacheDir.listFiles();
        if (cacheFiles != null) {
            for (File file : cacheFiles) {
                if (!file.isDirectory()) {
                    file.delete();
                } else {
                    delete(file);
                }
            }
        }
        return true;
    }

    /**
     * 判断是否离线
     * 
     * @param context
     * @return
     */
    public static boolean isOffline(Context context) {
        boolean offline = true;
        NetworkInfo netInfo = ((ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE))
                .getActiveNetworkInfo();

        if (netInfo != null && netInfo.isAvailable()) {
            offline = false;
        }

        return offline;
    }

    public static void linkTextView(TextView view) {
        String pattern = "((\\d{4}|\\d{3})?-?(\\d{7,8})(-\\d{1,2})?(\\d{1,2})?)|((\\d{4}|\\d{3})-(\\d{4}|\\d{3})-(\\d{4}|\\d{3}))";

        Linkify.addLinks(view, Linkify.EMAIL_ADDRESSES);
        Linkify.addLinks(view, Linkify.MAP_ADDRESSES);
        Linkify.addLinks(view, Linkify.WEB_URLS);
        Linkify.addLinks(view, Pattern.compile(pattern), "tel:");
    }

    public static Map<String, String> paramsToMap(String[] nvps) {
        if (nvps == null || nvps.length % 2 != 0) {
            throw new RuntimeException("Invalid Name Value Pairs ");
        }

        int size = nvps.length / 2;
        HashMap<String, String> res = new HashMap<String, String>(size);
        for (int i = 0; i < size; ++i) {
            res.put(nvps[2 * i], nvps[2 * i + 1]);
        }
        return res;
    }

    public static String[] mapToParams(Map<String, String> map) {
        int size = map.entrySet().size();

        String[] result = new String[size * 2];

        Iterator iter = map.entrySet().iterator();

        int i = 0;

        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            result[i++] = (String) entry.getKey();
            result[i++] = (String) entry.getValue();
        }

        return result;
    }

    public static float getMaxInArray(float[] array) {
        int length = array.length;
        int max = 0;

        for (int i = 1; i < length; i++) {
            if (array[max] < array[i]) {
                max = i;
            }
        }

        return array[max];
    }

    public static float getMinInArray(float[] array) {
        int length = array.length;
        int min = 0;

        for (int i = 1; i < length; i++) {
            if (array[min] > array[i]) {
                min = i;
            }
        }

        return array[min];
    }

    public static String[] getFormatDateLine(long dateline) {

        long[] date = Utils.countDown(dateline * 1000L);

        if (null == date) {// 团购结束
            return null;
        }

        String[] result = new String[4];

        long day = date[0];
        long hours = date[1];
        long mins = date[2];
        long secs = date[3];

        if (day > 0) {
            result[0] = day + "天";
            result[1] = hours + "时";
            result[2] = mins + "分";
        } else {
            result[0] = hours + "时";
            result[1] = mins + "分";
            result[2] = secs + "秒";
        }
        return result;
    }

    /**
     * 根据预期时间获取倒计时时间
     * 
     * @param time
     * @return long[],index:0表示天,1表示时,2表示分,3表示秒
     */
    public static long[] countDown(Long time) {
        if (time < new Date().getTime()) {
            return null;
        }

        long[] result = new long[4];
        Date now = new Date();
        long days = 0l, days_ = 0l;
        long hours = 0l, hours_ = 0l;
        long mins = 0l, mins_ = 0l;
        long secs = 0l;

        days = (time - now.getTime()) / (24 * 60 * 60 * 1000);
        days_ = (time - now.getTime()) % (24 * 60 * 60 * 1000);// 余下不足一天的毫秒数
        hours = days_ / (60 * 60 * 1000);// 计算出不足一天的小时数
        hours_ = days_ % (60 * 60 * 1000);// 余下不足一小时的毫秒数
        mins = hours_ / (60 * 1000);// 计算出不足一小时的分钟数
        mins_ = hours_ % (60 * 1000);// 余下不足一分钟的毫秒数
        secs = mins_ / (1000);// 计算出不足一分钟的秒数

        result[0] = days;
        result[1] = hours;
        result[2] = mins;
        result[3] = secs;

        return result;
    }

    public static double getDistance(Location location, double lat, double lng) {
        if (location == null) {
            return -1;
        }
        Location loc = new Location("");
        loc.setLatitude(lat);
        loc.setLongitude(lng);
        return loc.distanceTo(location);
    }

    public static String[] formatDistance(Double distance) {
        String[] result = new String[2];
        result[0] = "km";
        if (distance < 0) {
            result[1] = "";
            result[0] = "";
        } else if (distance <= 1000) {
            result[0] = "m";
            result[1] = new DecimalFormat("0").format(distance);
        } else if (distance > 1000 && distance < 10000) {
            result[1] = new DecimalFormat("0.1").format(distance / 1000);
        } else if (distance >= 10000) {
            result[1] = new DecimalFormat("0").format(distance / 1000);
        }
        return result;
    }

    // 从URL中解析出文件名
    // example input:
    // “http://www.meituan.com/content/deal/201003/jinqiaoyilu.jpg”
    // return: jinqiaoyilu.jpg
    public static String splitFileNameFromUrl(URL url) {
        String urlStr = url.toString();
        return urlStr.substring(urlStr.lastIndexOf((int) ('/')) + 1);
    }

    public static String[] mergeArray(String[] arr1, String[] arr2) {
        int length1 = arr1.length;
        int length2 = arr2.length;
        int length = length1 + length2;
        String[] result = new String[length];

        System.arraycopy(arr1, 0, result, 0, length1);
        System.arraycopy(arr2, 0, result, length1, length2);

        return result;
    }

    public static void exceptionShow(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示一个toast信息
     * 
     * @param context
     * @param msgid
     * @param longtime
     *            是否长时间显示
     */
    public static void msgShow(Context context, int msgid, boolean longtime) {
        String str = context.getString(msgid);
        msgShow(context, str, longtime);
    }

    public static void msgShow(Context context, String msg, boolean longtime) {
        Toast.makeText(context, msg,
                longtime ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
    }

    public static void msgShow(Context context, int msgid) {
        String str = context.getString(msgid);
        Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
    }

    public static void msgShow(Context context, String msg) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    public static boolean inArray(String key, String[] arr) {
        boolean flag = false;
        if (key.equals("")) {
            return flag;
        }

        if (arr.length <= 0) {
            return flag;
        }

        for (String name : arr) {
            if (key.equals(name)) {
                flag = true;
                break;
            }
        }

        return flag;
    }

    /**
     * 调用此函数，报错：!!! FAILED BINDER TRANSACTION !!!
     * 
     * @author leidiqiu @ 2012-06-26 15:33:01
     */
    public static boolean isPackageExist(Context context, String packageName) {
        PackageManager manager = context.getPackageManager();
        List<PackageInfo> pkgList = manager
                .getInstalledPackages(PackageManager.GET_ACTIVITIES);
        for (int i = 0; i < pkgList.size(); i++) {
            PackageInfo pI = pkgList.get(i);
            if (pI.packageName.equalsIgnoreCase(packageName))
                return true;
        }
        return false;
    }


    public static boolean checkEmail(String email) {
        boolean tag = true;
        String pattern1 = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(pattern1);
        Matcher mat = pattern.matcher(email);
        if (!mat.find()) {
            tag = false;
        }
        return tag;
    }

    public static boolean checkPhone(String phone) {
        boolean tag = true;
        String pattern1 = "((\\d{4}|\\d{3})?-?(\\d{7,8})(-\\d{1,2})?(\\d{1,2})?)|((\\d{4}|\\d{3})-(\\d{4}|\\d{3})-(\\d{4}|\\d{3}))";
        Pattern pattern = Pattern.compile(pattern1);
        Matcher mat = pattern.matcher(phone);
        if (!mat.find()) {
            tag = false;
        }
        return tag;
    }

    public static boolean checkMobilePhone(String phone) {
        boolean tag = true;
        if (phone.length() < 11) {
            return false;
        }

        String pattern1 = "((\\d{4}|\\d{3})?-?(\\d{7,8})(-\\d{1,2})?(\\d{1,2})?)|((\\d{4}|\\d{3})-(\\d{4}|\\d{3})-(\\d{4}|\\d{3}))";
        Pattern pattern = Pattern.compile(pattern1);
        Matcher mat = pattern.matcher(phone);
        if (!mat.find()) {
            tag = false;
        }
        return tag;
    }

    public static String formatMobilePhone(String phone) {
        final String replacement = "$1****$3";
        return phone.replaceAll("(\\d{3})([^<>]*)(\\d{4})", replacement);
    }

    public static byte[] getBytesFromInputStream(InputStream is, int bufsiz)
            throws IOException {
        int total = 0;
        byte[] bytes = new byte[4096];
        ByteBuffer bb = ByteBuffer.allocate(bufsiz);

        while (true) {
            int read = is.read(bytes);
            if (read == -1)
                break;
            bb.put(bytes, 0, read);
            total += read;
        }

        byte[] content = new byte[total];
        bb.flip();
        bb.get(content, 0, total);

        return content;
    }

    public static Bitmap getPicFromBytes(byte[] bytes,
            BitmapFactory.Options opts) throws OutOfMemoryError {

        if (bytes != null)
            if (opts != null)
                return BitmapFactory.decodeByteArray(bytes, 0, bytes.length,
                        opts);
            else
                return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        return null;
    }

    public static boolean createFile(String destFileName) throws IOException {

        boolean flag = true;
        File file = new File(destFileName);
        if (file.exists()) {
            file.delete();
        }

        // create dir
        if (!file.getParentFile().exists()) {
            if (!file.getParentFile().mkdirs()) {
                flag = false;
            }
        }

        // create file
        try {
            if (!file.createNewFile()) {
                flag = false;
            }
        } catch (IOException e) {
            throw e;
        }
        return flag;
    }

    public static String toHtml(String str) {
        String html = str;
        html = replace(html, "&amp;", "&");
        html = replace(html, "&lt;", "<");
        html = replace(html, "&gt;", ">");
        html = replace(html, "\n", "\r\n");
        html = replace(html, "<br>\n", "\n");
        html = replace(html, "         ", "\t");
        html = replace(html, "   &nbsp;", "     ");
        return html;
    }

    public static String replace(String source, String oldString,
            String newString) {
        StringBuffer output = new StringBuffer();
        int lengthOfSource = source.length(); // 源字符串长度
        int lengthOfOld = oldString.length(); // 老字符串长度
        int posStart = 0; // 开始搜索位置
        int pos; // 搜索到老字符串的位置
        while ((pos = source.indexOf(oldString, posStart)) >= 0) {
            output.append(source.substring(posStart, pos));
            output.append(newString);
            posStart = pos + lengthOfOld;
        }
        if (posStart < lengthOfSource) {
            output.append(source.substring(posStart));
        }
        return output.toString();
    }

    // 过滤通过页面表单提交的字符
    private static final String[][] FILTER_CHARS = { { "<", "&lt;" },
            { ">", "&gt;" }, { " ", "&nbsp;" }, { "\"", "&quot;" },
            { "&", "&amp;" }, { "/", "&#47;" }, { "\\\\", "&#92;" },
            { "\n", "<br>" }, { "“", "&ldquo;" }, { "”", "&rdquo;" } };

    public static Calendar getDate(Date when) {
        Calendar cl = Calendar.getInstance();
        cl.setTime(when);
        int year = cl.get(Calendar.YEAR);
        int month = cl.get(Calendar.MONTH);
        int date = cl.get(Calendar.DATE);

        cl.clear();
        cl.set(year, month, date);
        return cl;
    }

    public static boolean isChinese(char c) {

        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);

        if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS

        || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS

        || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A

        || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION

        || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION

        || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {

            return true;

        }

        return false;

    }

    public static boolean isChinese(String strName) {

        char[] ch = strName.toCharArray();

        boolean flag = false;
        for (int i = 0; i < ch.length; i++) {

            char c = ch[i];

            if (isChinese(c) == true) {

                flag = true;
                break;
            }
        }

        return flag;
    }

    public static Calendar getToday() {
        return getDate(new Date());
    }

    public static String formartToday() {
        String[] dayofweek = { "天", "一", "二", "三", "四", "五", "六" };
        Calendar calendar = getToday();
        StringBuffer result = new StringBuffer();
        result.append(calendar.get(Calendar.YEAR));
        result.append("年");
        result.append(calendar.get(Calendar.MONTH) + 1);
        result.append("月");
        result.append(calendar.get(Calendar.DAY_OF_MONTH));
        result.append("日");
        result.append("  星期");
        result.append(dayofweek[calendar.get(Calendar.DAY_OF_WEEK) - 1]);

        return result.toString();
    }

    /**
     * 格式化字符串，以size为一个单位，用delimiter连接起来
     * 
     * @param str
     * @param delimiter
     * @param size
     * @return
     */
    public static String strFormat(String str, String oldDelimiter, int size) {
        String delimiter = oldDelimiter;
        if ("".equals(str)) {
            return "";
        }

        if (size <= 0) {
            return str;
        }

        if ("".equals(delimiter)) {
            delimiter = " ";
        }

        StringBuffer result = new StringBuffer();

        int count = str.length();// 总数

        int block = (count % size) > 0 ? (count / size) + 1 : count / size;

        for (int i = 0; i < block; i++) {
            String tmp = "";
            if (i == block - 1) {
                tmp = str.substring(i * size);
                result.append(tmp);
            } else {
                tmp = str.substring(i * size, i * size + size);
                result.append(tmp);
                result.append(delimiter);
            }
        }

        return result.toString();
    }

    /**
     * 删除input字符串中的html格式
     * 
     * @param html
     * @return
     */
    public static String replaceHtml(String html) {
        if (TextUtils.isEmpty(html)) {
            return "";
        }
        String regEx = "<.+?>"; // 表示标签
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(html);
        String s = m.replaceAll("");
        return s;
    }

    public static String filtePhone(String phone) {
        if (TextUtils.isEmpty(phone)) {
            return "";
        }
        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(phone);
        String s = m.replaceAll("");
        return s;
    }

    /**
     * 给定字符串，返回字符串中连续的4个数字，用于提取验证短信中的验证码。 例如："美团：短信验证码是：1234，请填写到网站上完成验证。" , 返回
     * "1234"
     * 
     * @param s
     *            一个字符串
     * @return 字符串中连续的4个数字。
     * @author leidiqiu
     */
    public static String get4ContinuousDigital(String s) {

        // 连续4个数字的正则表达式
        Pattern p = Pattern.compile("\\d{4}");
        Matcher m = p.matcher(s);
        if (m.find()) {
            String s11 = m.group();
            return s11;
        } else {
            return "";
        }
    }

    /**
     * 给定两个日期，返回两个日期相差的天数
     * 
     * @param date1
     * @param date2
     * @return 两个日期相差的天数
     * @author dingzhihu
     */
    public static int getDateOffset(Date date1, Date date2) {
        int offset = 0;
        offset = (int) ((date1.getTime() - date2.getTime()) / 3600 / 24 / 1000);
        return offset;
    }

    /**
     * 返回格式化的日期
     * 
     * @return 日期字符串
     */
    public static String getFormattedDateStr() {
        Date now = new Date();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        return df.format(now);
    }

    /**
     * 根据DateFormat返回日期字符串
     * 
     * @param df
     * @param date
     * @return
     */
    public static String getDateStrByDateFormat(DateFormat df, Date date) {
        return df.format(date);
    }

    /**
     * 
     * @author mashengchao 2011-12-7 上午09:49:48
     * @param lngDate
     *            以秒为单位的的时间
     * @return
     */
    public static String getDateForDisplay(long lngDate) {
        if (lngDate == 0) {
            return "上次没有更新";
        }
        Date date = null;
        try {
            date = new Date(lngDate * 1000l);
        } catch (Exception e) {
            
        }
        if (date == null) {
            return "上次没有更新";
        }
        String strDf = SHORT_DATE_FORMAT;

        long now = date.getTime();

        long today = getToday().getTimeInMillis();

        long yestoday = today - 24 * 60 * 60 * 1000;

        if (now >= today) {
            return "今天"
                    + getDateStrByDateFormat(new SimpleDateFormat(strDf), date);
        } else if (now >= yestoday) {
            return "昨天"
                    + getDateStrByDateFormat(new SimpleDateFormat(strDf), date);
        } else {
            strDf = LONG_DATE_FORMAT;
            return getDateStrByDateFormat(new SimpleDateFormat(strDf), date);
        }
    }

    /**
     * 根据milliseconds返回日期字符串
     * 
     * @param millis
     * @return
     */
    public static String getDateStrByMillis(long millis) {
        if (millis == 0L) {
            return "";
        }
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(millis);
        Date date = cal.getTime();
        DateFormat df = new SimpleDateFormat(LONG_DATE_FORMAT);
        return df.format(date);
    }

    public static boolean isToday(long startAt) {
        long today = Utils.getToday().getTimeInMillis() / 1000;
        long tomorrow = today + 24 * 60 * 60;

        if (startAt >= today && startAt < tomorrow) {
            return true;
        }

        return false;
    }

    public static void cleanUpSdcardDir(Context context) {
        String externalCacheDir = String.format("/Android/data/%s/cache/",
                context.getPackageName());
        File sdcardDir = new File(Environment.getExternalStorageDirectory()
                .getAbsolutePath() + externalCacheDir);
        File[] sdcardFiles = sdcardDir.listFiles();
        deleteFile(sdcardFiles);

        File cacheDir = context.getCacheDir();
        File[] cacheFiles = cacheDir.listFiles();
        deleteFile(cacheFiles);
    }

    public static void cleanUpDataDir(Context context) {
        String externalCacheDir = String.format("/Android/data/%s/cache/",
                context.getPackageName());
        File sdcardDir = new File(Environment.getExternalStorageDirectory()
                .getAbsolutePath() + externalCacheDir);
        File[] sdcardFiles = sdcardDir.listFiles();
        deleteFile(sdcardFiles);

        File dataDir = new File("/data/data/" + context.getPackageName());
        File[] dataFiles = dataDir.listFiles();
        deleteFile(dataFiles);
    }

    private static void deleteFile(File[] files) {
        if (files != null) {
            for (File file : files) {
                try {
                    if (!file.isDirectory()) {
                        file.delete();
                    } else {
                        delete(file);
                    }
                } catch (Exception ex) {
                }
            }
        }
    }

    /**
     * 判断当前程序是否正在运行（是否有未退出的咱们的Activity）
     */
    public static boolean isRunning(Context context) {
        ActivityManager activityManager = (ActivityManager) context
                .getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningTaskInfo> list = activityManager
                .getRunningTasks(100);
        boolean isRunning = false;
        // 判断我们是否在正常运行。
        for (int i = 0; i < list.size(); i++) {
            ActivityManager.RunningTaskInfo task = list.get(i);
            if ((task.baseActivity != null && context.getPackageName().equals(
                    task.baseActivity.getPackageName()))
                    || (task.topActivity != null && context.getPackageName()
                            .equals(task.topActivity.getPackageName()))) {
                isRunning = true;
                break;
            }
        }
        return isRunning;
    }

    /**
     * 判断当前程序是否正在使用（屏幕最前端的Activity是不是咱们的）
     */
    public static boolean isAppInUse(Context context) {
        ActivityManager activityManager = (ActivityManager) context
                .getSystemService(Context.ACTIVITY_SERVICE);

        List<ActivityManager.RunningTaskInfo> list = activityManager
                .getRunningTasks(1);
        boolean isAppInUse = false;
        // 判断我们是否在正常运行。
        if (list != null && list.size() > 0) {
            ActivityManager.RunningTaskInfo task = list.get(0);
            if ((task.baseActivity != null && context.getPackageName().equals(
                    task.baseActivity.getPackageName()))
                    || (task.topActivity != null && context.getPackageName()
                            .equals(task.topActivity.getPackageName()))) {
                isAppInUse = true;
            }
        }
        return isAppInUse;
    }

    // 返回四舍五入后只有一位小数的double值
    public static String getFormattedDoubleValue(double rawValue) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(rawValue);
    }

}
