package com.test.celllocate.utils;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.params.ConnRoutePNames;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;

/**
 * 设置APN信息的类
 * 
 * @author chenhongbing
 */
public class ApnSetUtils {
    /**
     * 设置httpClient的代理，默认使用系统代理，没有系统代理时设置默认值。
     * 
     * @param context
     * @param client
     */
    public static void setAPN(Context context, HttpClient client) {
        String apn = APNMatchTools.matchAPN(Utils.getCurrentAPN(context));

        if (!Utils.isNetworkWifi(context)) {
            // 获取当前ＡＰＮ信息的ＵＲＩ
            Uri apnUri = Uri.parse("content://telephony/carriers/preferapn");
            // 查询当前的网络的ＡＰＮ信息
            Cursor cr = null;
            try {
                cr = context.getContentResolver().query(apnUri, null,
                        "apn = ?", new String[] { apn }, null);
            } catch (Exception ex) {
                cr = null;
            }
            String apnProxy = "";
            int apnPort = 0;
            // 取得当前网络状态的代理
            if (cr != null && cr.getCount() > 0) {
                cr.moveToFirst();
                // APN proxy
                apnProxy = cr.getString(cr.getColumnIndex("proxy"));
                try {
                    // APN port
                    apnPort = cr.getInt(cr.getColumnIndex("port"));
                } catch (NumberFormatException ex) {
                    apnPort = 80;
                }
                cr.close();
            } else {
                // 当手机中没有默认ＡＰＮ设置时，按照规则设置的默认代理
                if (apn.equals(APNMatchTools.APNNet.CMWAP)
                        || apn.equals(APNMatchTools.APNNet.GWAP_3)
                        || apn.equals(APNMatchTools.APNNet.UNIWAP)) {
                    // 移动ＷＡＰ，联通ＷＡＰ，3ＧＷＡＰ
                    apnProxy = "10.0.0.172";
                    apnPort = 80;
                }
                if (apn.equals(APNMatchTools.APNNet.CTWAP)) {
                    // 电信ＷＡＰ
                    apnProxy = "10.0.0.200";
                    apnPort = 80;
                }
            }
            // 如果有代理，设置代理，一般都是ｗａｐ网络状况下需要设置代理
            // 中国电信的ｗａｐ和ｎｅｔ合并成ｗａｐ了。
            if (!TextUtils.isEmpty(apnProxy)) {
                HttpHost proxy = new HttpHost(apnProxy, apnPort, "http");
                client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY,
                        proxy);
            } else {
                client.getParams().removeParameter(
                        ConnRoutePNames.DEFAULT_PROXY);
            }
        } else {
            client.getParams().removeParameter(ConnRoutePNames.DEFAULT_PROXY);
        }
    }
}
