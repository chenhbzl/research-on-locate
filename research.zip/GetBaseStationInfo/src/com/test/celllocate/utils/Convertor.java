package com.test.celllocate.utils;


import java.io.InputStream;

public interface Convertor<T> {
    T convert(InputStream inputStream) throws Exception;

}
