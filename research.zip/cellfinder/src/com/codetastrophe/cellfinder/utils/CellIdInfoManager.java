package com.codetastrophe.cellfinder.utils;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.telephony.NeighboringCellInfo;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;

import com.codetastrophe.cellfinder.bean.CellData;

/**
 * 
 * @author chenhongbing
 * 
 */
public class CellIdInfoManager {

    private Context context;

    public CellIdInfoManager(Context context) {
        this.context = context;
    }

    public List<CellData> getCellInfo() {
        List<CellData> listInfo = new ArrayList<CellData>();

        int countryCode = 460;
        int networkCode = 0;
        int signalStrength = (int) (-50 * Math.random() - 50); // 定位和它关系不大
        CellData info = new CellData();

        TelephonyManager manager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);
        if (manager.getCellLocation() instanceof GsmCellLocation) {
            GsmCellLocation gsm = (GsmCellLocation) manager.getCellLocation();
            if (gsm == null) {
                return listInfo;
            }
            if (manager.getNetworkOperator() == null
                    || manager.getNetworkOperator().length() == 0) {
                return listInfo;
            }
            try {
                countryCode = Integer.parseInt(manager.getNetworkOperator()
                        .substring(0, 3));
                networkCode = Integer.parseInt(manager.getNetworkOperator()
                        .substring(3, 5));
            } catch (Exception ex) {
                countryCode = 460;
                int networkType = manager.getNetworkType();
                if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                        || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                    networkCode = 0;
                } else {
                    networkCode = 1;
                }
            }

            String radioType = "";
            int networkType = manager.getNetworkType();
            if (networkType == TelephonyManager.NETWORK_TYPE_GPRS
                    || networkType == TelephonyManager.NETWORK_TYPE_EDGE) {
                radioType = "gsm";
            } else {
                radioType = "wcdma";
            }
            info.cid = gsm.getCid();
            info.mcc = countryCode;
            info.mnc = networkCode;
            info.lac = gsm.getLac();
            info.radioType = radioType;
            info.signalStrength = signalStrength;
            info.time = System.currentTimeMillis();

            listInfo.add(info);

            List<NeighboringCellInfo> list = manager.getNeighboringCellInfo();
            for (NeighboringCellInfo i : list) {
                CellData ci = new CellData();
                ci.cid = i.getCid();
                ci.mcc = countryCode;
                ci.mnc = networkCode;
                ci.lac = i.getLac();
                ci.radioType = radioType;
                ci.signalStrength = 2 * i.getRssi() - 113;
                ci.time = System.currentTimeMillis();
                listInfo.add(ci);
            }
        } else if (manager.getCellLocation() instanceof CdmaCellLocation) {
            CdmaCellLocation cdma = (CdmaCellLocation) manager
                    .getCellLocation();
            if (cdma == null) {
                return listInfo;
            }
            if (manager.getNetworkOperator() == null
                    || manager.getNetworkOperator().length() == 0) {
                return listInfo;
            }
            try {
                countryCode = Integer.parseInt(manager.getNetworkOperator());
            } catch (Exception ex) {
                countryCode = 460;
            }
            info.cid = cdma.getBaseStationId();
            info.mcc = countryCode;
            info.mnc = cdma.getSystemId();
            info.lac = cdma.getNetworkId();
            info.radioType = "cdma";
            info.time = System.currentTimeMillis();
            listInfo.add(info);
        }
        return listInfo;
    }
}