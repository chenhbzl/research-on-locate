package com.codetastrophe.cellfinder.bean;

public class WifiData {
    public String bssid;
    public int level;
}
