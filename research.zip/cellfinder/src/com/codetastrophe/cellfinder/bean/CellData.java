/*jadclipse*/// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.

package com.codetastrophe.cellfinder.bean;

public class CellData {

    public CellData() {
    }

    public int cid;
    public int lac;
    public int mcc;
    public int mnc;
    public long time;
    public String radioType;
    public int signalStrength;
}

/*
 * DECOMPILATION REPORT
 * 
 * Decompiled from:
 * /Users/chenhongbing/dev/workspace/TestBaiduLocate/libs/location-1.0.4.jar
 * Total time: 21 ms Jad reported messages/errors: Exit status: 0 Caught
 * exceptions:
 */