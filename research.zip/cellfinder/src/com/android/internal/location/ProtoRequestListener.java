// Copyright 2007 The Android Open Source Project

package com.android.internal.location;

//import com.google.common.io.GoogleHttpConnection;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import android.util.Log;

import com.codetastrophe.cellfinder.utils.ByteToFile;
import com.codetastrophe.cellfinder.utils.InputStreamUtils;
import com.google.common.io.protocol.ProtoBuf;
import com.google.masf.ServiceCallback;
import com.google.masf.protocol.Request;
import com.google.masf.protocol.Response;
import com.google.masf.services.AsyncResult;

/**
 * Listener for protocol buffer requests
 * 
 * {@hide}
 */

public class ProtoRequestListener implements Request.Listener {
    private final static String TAG = "ProtoRequestListener";
    private AsyncResult result;
    private ProtoBuf protoResponse;

    /**
     * @return the asynchronous result object
     */
    public AsyncResult getAsyncResult() {
        return result;
    }

    /**
     * Constructor for a ProtoRequestListener
     * 
     * @param protoResponse
     *            ProtoBuf with correct type to fill response with
     * @param callback
     *            function to call after completed request (may be null)
     */
    public ProtoRequestListener(ProtoBuf protoResponse, ServiceCallback callback) {
        this.result = new AsyncResult(callback);
        this.protoResponse = protoResponse;
    }

    // public boolean requestComplete(Request request, Response response)
    // throws IOException {
    // InputStream is = response.getInputStream();
    // if (response.getStatusCode() == 200) {
    // protoResponse.parse(is);
    // result.setResult(protoResponse);
    // } else {
    // result.setResult(null);
    // }
    // return true;
    // }

    @Override
    public void requestFailed(Request request, Exception exception) {
        String data = "";
        byte[] requestbytes = null;
        try {
            InputStream is = request.getInputStream();
            requestbytes = InputStreamUtils.InputStreamTOByte(is);
            ByteToFile.getFile(requestbytes, "/sdcard", "locate_by_wifi_3.txt");
            data = new String(requestbytes,"UTF-8");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Log.e(TAG, "requestdata = " + data);
        Log.e(TAG, "requestException()", exception);
    }

    @Override
    public void requestCompleted(Request request, Response response) {
        String data = "";
        byte[] requestbytes = null;
//        try {
//            InputStream is = request.getInputStream();
//            requestbytes = InputStreamUtils.InputStreamTOByte(is);
//            ByteToFile.getFile(requestbytes, "/sdcard", "locate_by_wifi_3.txt");
//            data = new String(requestbytes,"UTF-8");
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
        Log.e(TAG, "requestdata = " + data);
        try {
            InputStream is = response.getInputStream();
            if (response.getStatusCode() == 200) {
//                try {
//                    requestbytes = InputStreamUtils.InputStreamTOByte(is);
//                    ByteToFile.getFile(requestbytes, "/sdcard", "locate_by_jieguo_3.txt");
//                    data = new String(requestbytes,"UTF-8");
//                } catch (Exception e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
//                Log.e(TAG, "response data = " + data);
                protoResponse.parse(is);
                result.setResult(protoResponse);
            } else {
                result.setResult(null);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
