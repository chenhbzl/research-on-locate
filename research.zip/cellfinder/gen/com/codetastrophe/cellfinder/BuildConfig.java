/** Automatically generated file. DO NOT MODIFY */
package com.codetastrophe.cellfinder;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}