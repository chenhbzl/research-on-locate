package util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import org.apache.http.protocol.HTTP;

public class StringConvertor implements Convertor<String> {

    private static int BUFFER_SIZE = 4096;

    public String convert(InputStream inputStream) throws Exception {

        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        byte[] data = new byte[BUFFER_SIZE];
        int count = -1;
        while ((count = inputStream.read(data, 0, BUFFER_SIZE)) != -1) {
            outStream.write(data, 0, count);
        }
        data = null;
        return new String(outStream.toByteArray(), HTTP.UTF_8);
    }
}
