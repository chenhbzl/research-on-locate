package util;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class Get<T> {
    String mUrl = "";
    String[] mParams = {};
    Convertor<T> mConvertor;

    public Get(String u) {
        mUrl = u;
    }

    public Get(String u, String[] p) {
        mUrl = u;
        mParams = p;
    }

    public Get<T> setConvertor(Convertor<T> convertor) {
        mConvertor = convertor;
        return this;
    }

    public String getFullUrl() {
        StringBuffer params = new StringBuffer();
        for (int i = 0; i < mParams.length; i = i + 2) {
            if (i == mParams.length - 2) {
                params.append(mParams[i]).append("=").append(mParams[i + 1]);
            } else {
                params.append(mParams[i]).append("=").append(mParams[i + 1])
                        .append("&");
            }
        }
        String url = mUrl;
        if (mParams != null && mParams.length > 0) {
            url = mUrl + "?" + params;
        }
        return url;
    }

    public T getResult() {
        try {
            StringBuffer params = new StringBuffer();
            for (int i = 0; i < mParams.length; i = i + 2) {
                if (i == mParams.length - 2) {
                    params.append(URLEncoder.encode(mParams[i], "UTF-8"))
                            .append("=")
                            .append(URLEncoder.encode(mParams[i + 1], "UTF-8"));
                } else {
                    params.append(URLEncoder.encode(mParams[i], "UTF-8"))
                            .append("=")
                            .append(URLEncoder.encode(mParams[i + 1], "UTF-8"))
                            .append("&");
                }
            }
            URL url = new URL(mUrl);
            if (mParams != null && mParams.length > 0) {
                url = new URL(mUrl + "?" + params);
            } else {
                url = new URL(mUrl);
            }

            URLConnection rulConnection = url.openConnection();
            HttpURLConnection httpUrlConnection = (HttpURLConnection) rulConnection;
            httpUrlConnection.setConnectTimeout(300000);
            httpUrlConnection.addRequestProperty("http.useragent",
                    "陈红兵测试全渠道升级接口");
            httpUrlConnection.setReadTimeout(300000);
            httpUrlConnection.setDoOutput(false);
            httpUrlConnection.connect();

            InputStream inStrm = httpUrlConnection.getInputStream();
            return mConvertor.convert(inStrm);
        } catch (Exception e) {
            e.printStackTrace();
            return (T) e.toString();
        }
    }
}
