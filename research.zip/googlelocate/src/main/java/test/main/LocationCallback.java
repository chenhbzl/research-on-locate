package test.main;

public interface LocationCallback {

    void GotLocation(String postData, double lat, double lon, int acc);

    void Error(String msg);
}
