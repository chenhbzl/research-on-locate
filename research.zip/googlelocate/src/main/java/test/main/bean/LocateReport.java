package test.main.bean;

import java.util.ArrayList;
import java.util.List;

import test.main.CellData;
import test.main.WifiData;
import util.TransformLocation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;

public class LocateReport {
    @JSONField(name = "source")
    private String source = "";
    @JSONField(name = "response")
    private String response = "";
    @JSONField(name = "request")
    private JSONObject request = null;

    private double lat = 0;
    private double lng = 0;
    private boolean isGetMarLatLng = false;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public JSONObject getRequest() {
        return request;
    }

    public void setRequest(JSONObject request) {
        this.request = request;
    }

    public boolean isNetwork() {
        return "network".equals(source) || "gps".equals(source);
    }

    public boolean canTest() {
        return "baidu".equals(source) || "network".equals(source)
                || "gps".equals(source);
    }

    public boolean isMars() {
        return "choose".equals(source) || "baidu".equals(source);
    }

    public boolean isBaidu() {
        return "baidu".equals(source);
    }

    private void computerLatLng() {
        if (isNetwork()) {
            JSONObject jsonObject = JSONObject.parseObject(response);
            double longitude = jsonObject.getDouble("latitude");
            double latitude = jsonObject.getDouble("longitude");
            // if (isMars()) {
            // lat = latitude;
            // lng = longitude;
            // } else {
            double[] mgLatLng = TransformLocation.gps2mars(latitude, longitude);
            lat = mgLatLng[1];
            lng = mgLatLng[0];
            // }
        }
        if (isBaidu()) {
            JSONObject jsonObject = JSONObject.parseObject(response);
            JSONObject contentJSON = jsonObject.getJSONObject("content");
            JSONObject resultJSON = jsonObject.getJSONObject("result");
            double radius = contentJSON.getDouble("radius");
            JSONObject pointJSON = contentJSON.getJSONObject("point");
            lng = pointJSON.getDouble("x");
            lat = pointJSON.getDouble("y");
        }
    }

    public double getLatMars() {
        if (!isGetMarLatLng) {
            computerLatLng();
            isGetMarLatLng = true;
        }
        return lat;
    }

    public double getLngMars() {
        if (!isGetMarLatLng) {
            computerLatLng();
            isGetMarLatLng = true;
        }
        return lng;
    }

    public boolean isEquals(double lat1, double lng1) {
        double lat2 = getLatMars();
        double lng2 = getLngMars();

        return equals(lat1, lat2) && equals(lng1, lng2);
    }

    private boolean equals(double d1, double d2) {
        final int foo = 1;
        int i1 = (int) Math.round(d1 * foo);
        int i2 = (int) Math.round(d2 * foo);
        return i1 == i2;
    }

    public List<WifiData> getWifiData() {
        List<WifiData> listWifiData = new ArrayList<WifiData>();
        JSONArray jsonarr = request.getJSONArray("wifi_towers");
        if (jsonarr != null) {
            int size = jsonarr.size();
            for (int i = 0; i < size; i++) {
                JSONObject jsonObj = jsonarr.getJSONObject(i);
                WifiData wifidata = new WifiData();
                wifidata.bssid = jsonObj.getString("mac_address");
                wifidata.level = jsonObj.getIntValue("signal_strength");
                listWifiData.add(wifidata);
            }
        }

        return listWifiData;
    }

    public List<CellData> getCellData() {
        List<CellData> listCellData = new ArrayList<CellData>();
        JSONArray jsonarr = request.getJSONArray("cell_towers");
        if (jsonarr != null) {
            int size = jsonarr.size();
            for (int i = 0; i < size; i++) {
                JSONObject jsonObj = jsonarr.getJSONObject(i);
                CellData celldata = new CellData();
                celldata.cid = jsonObj.getIntValue("cell_id");
                celldata.lac = jsonObj.getIntValue("location_area_code");
                celldata.mcc = jsonObj.getIntValue("mobile_country_code");
                celldata.mnc = jsonObj.getIntValue("mobile_network_code");
                celldata.signalStrength = jsonObj
                        .getIntValue("signal_strength");
                celldata.radioType = request.getString("radio_type");
                if ("wcdma".equals(celldata.radioType)) {
                    celldata.mnc = 1;
                }
                celldata.time = System.currentTimeMillis();
                listCellData.add(celldata);
            }
        }
        return listCellData;
    }
}
