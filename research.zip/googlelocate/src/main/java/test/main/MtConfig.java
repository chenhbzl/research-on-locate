package test.main;

import com.google.common.Config;
import com.google.common.graphics.FontFactory;
import com.google.common.graphics.ImageFactory;
import com.google.common.io.Gunzipper;
import com.google.common.io.HttpConnectionFactory;
import com.google.common.io.InMemoryPersistentStore;
import com.google.common.io.PersistentStore;
import com.google.common.ui.NativeTextFieldFactory;

public class MtConfig extends Config {

    @Override
    public String getAppProperty(String s) {
        return null;
    }

    @Override
    public HttpConnectionFactory getConnectionFactory() {
        return null;
    }

    @Override
    public PersistentStore getPersistentStore() {
        return new InMemoryPersistentStore();
    }

    @Override
    protected void setupGzipper() {

        Gunzipper.setImplementation(new MtGunzipInterface());
    }

    @Override
    public FontFactory getFontFactory() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int getGameAction(Object arg0, int arg1) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public ImageFactory getImageFactory() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public NativeTextFieldFactory getNativeTextFieldFactory() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public int getPixelsPerInch() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public String getVersion() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isFire(Object arg0, int arg1) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean supportsTranslucency() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    protected boolean testSupportsJpeg() {
        // TODO Auto-generated method stub
        return false;
    }

}
