package test.main;

public class WifiData {
    public String bssid;
    public int level;
}
