package test.main;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HttpContext;

import test.main.bean.LocateReport;
import util.Get;
import util.InputStreamUtils;
import util.StringConvertor;
import util.TransformLocation;

import com.alibaba.fastjson.JSON;
import com.android.internal.location.protocol.GCell;
import com.android.internal.location.protocol.GCellularProfile;
import com.android.internal.location.protocol.GDeviceLocation;
import com.android.internal.location.protocol.GLatLng;
import com.android.internal.location.protocol.GLocReply;
import com.android.internal.location.protocol.GLocReplyElement;
import com.android.internal.location.protocol.GLocRequest;
import com.android.internal.location.protocol.GLocRequestElement;
import com.android.internal.location.protocol.GLocation;
import com.android.internal.location.protocol.GPlatformProfile;
import com.android.internal.location.protocol.GPrefetchMode;
import com.android.internal.location.protocol.GWifiDevice;
import com.android.internal.location.protocol.GWifiProfile;
import com.android.internal.location.protocol.GcellularMessageTypes;
import com.android.internal.location.protocol.GlocationMessageTypes;
import com.android.internal.location.protocol.GwifiMessageTypes;
import com.android.internal.location.protocol.LocserverMessageTypes;
import com.android.internal.location.protocol.ResponseCodes;
import com.google.android.net.GoogleHttpClient;
import com.google.common.Config;
import com.google.common.io.Gunzipper;
import com.google.common.io.protocol.ProtoBuf;
import com.google.masf.DelimitedInputStream;
import com.google.masf.protocol.HeaderRequest;
import com.google.masf.protocol.MultipartResponse;
import com.google.masf.protocol.PlainRequest;
import com.google.masf.protocol.PlainResponse;
import com.google.masf.protocol.Request;
import com.google.masf.protocol.Response;

public class TestMain {

    private static final String REQUEST_QUERY_LOC = "g:loc/ql";
    private static final String[] HOST = new String[] { "http://74.125.31.105/" };
    private static final String HTTPS_MASF_SERVER_ADDRESS = "https://www.google.com/loc/m/api";
    private static final String HTTP_MASF_SERVER_ADDRESS = "http://www.google.com/loc/m/api";
    private static final String APPLICATION_NAME = "location";
    private static final String APPLICATION_VERSION = "1.0";
    private static final String PLATFORM_ID = "android";
    private static final String DISTRIBUTION_CHANNEL = "android";
    private static final String PLATFORM_BUILD = "android";

    private static final double E7 = 10000000.0;

    private static final int MAX_WIFI_TO_INCLUDE = 20;

    /**
     * @param args
     * @throws FileNotFoundException
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        // 初始化基站和wifi mac地址列表
        // initwifidata();
        // initgsmcelldata();
        // initwcdmacelldata();
        // initcdmacelldata();
        String perLine;
        final long time = System.currentTimeMillis();
        final String path = "/Users/chenhongbing/dev/workspace/googlelocate/src/main/java/";
        BufferedReader line = new BufferedReader(new InputStreamReader(
                new FileInputStream(path + "locatereport-2013-03-20_00011"),
                "UTF-8"));
        String strlineseparator = System.getProperty("line.separator");
        // 必须设置一个config，否则获取CookieService.getInstance().getCookie()时会空指针
        Config.setConfig(new MtConfig());
        // 必须设置，用来解析google返回的数据
        Gunzipper.setImplementation(new MtGunzipInterface());

        // 做成一个头部信息
        HeaderRequest headerRequest = new HeaderRequest(APPLICATION_NAME,
                APPLICATION_VERSION, PLATFORM_ID, DISTRIBUTION_CHANNEL, "g");

        byte[] postHeader1ByteArr = null;

        postHeader1ByteArr = InputStreamUtils.InputStreamTOByte(headerRequest
                .getInputStream());

        // google nexus S的UA是这样设置的，其他手机需要变化
        String userAgent = "GoogleMobile/1.0 (crespo JZO54K)";
        // 此处GoogleHttpClient可以使用DefaultHttpClient替代，请求同样成功，但是不知道会不会有副作用
        // 区别：DefaultHttpClient发送的头里面有“Expect:100-continue”
        // GoogleHttpClient没有“Expect:100-continue”
        // 用GoogleHttpClident的话，抓包的数据效果和安卓手机的cellfinder程序的net定位效果一样
        ThreadSafeClientConnManager connectionManager = new ThreadSafeClientConnManager();
        connectionManager.setDefaultMaxPerRoute(300);
        NoCookieHttpClient client = new NoCookieHttpClient(connectionManager);
        client.getParams().setParameter("http.connection.timeout",
                Integer.valueOf(15000));
        client.getParams().setParameter("http.socket.timeout",
                Integer.valueOf(15000));
        client.getParams().setParameter("http.useragent", userAgent);
        client.getParams().setParameter("http.protocol.handle-redirects", true);
        // GoogleHttpClient client = new GoogleHttpClient(userAgent,
        // true);
        int index = 0;
        while ((perLine = line.readLine()) != null) { // 已读去一行,信息保存在perLine中

            String jsondata = perLine.substring(54);

            try {
                LocateReport reportBean = JSON.parseObject(jsondata,
                        LocateReport.class);
                listWifiData = reportBean.getWifiData();
                listCellData = reportBean.getCellData();
                if (listCellData.size() > 0
                        && (listCellData.get(0).cid <= 0 || listCellData.get(0).lac <= 0)) {
                    continue;
                }

                // 做成基站和wifi mac地址等主要定位信息
                byte[] postBody = makePostData();

                // 生成整个post请求的byte流
                byte[] postData = null;
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                try {
                    bos.write(postHeader1ByteArr);
                    bos.write(postBody);
                    bos.flush();
                    postData = bos.toByteArray();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        bos.close();
                    } catch (IOException e) {
                    }
                }

                // 此处除了HTTP协议可以使用外，还可以使用HTTPS协议
                String url = HTTPS_MASF_SERVER_ADDRESS;

                HttpPost post = new HttpPost(url);
                post.addHeader("Content-Type", "application/binary");
//                String ip = getIp();
//                System.out.println(ip);
//                post.addHeader("x-forwarded-for", ip);
                post.setEntity(new ByteArrayEntity(postData));

                HttpResponse response = client.execute(post);

                StatusLine status = response.getStatusLine();
                if (status.getStatusCode() != 200) { // HTTP 200 is success.
                    response.getEntity().getContent().close();
                    throw new IOException("HTTP error: "
                            + status.getReasonPhrase());
                } else {
                    // System.out.println("HTTP code 200.");
                }
                // 转译一下google返回的数据
                Response responseChange = processInputStream(response
                        .getEntity().getContent());
                // 按照一定规则来分析转译后的数据
                ProtoBuf protoResponse = new ProtoBuf(
                        LocserverMessageTypes.GLOC_REPLY);
                protoResponse.parse(responseChange.getInputStream());

                // // 读取定位相关信息
                double[] mars = new double[2];
                mars = parseNetworkLocationReply(protoResponse);

                if (!reportBean.isEquals(mars[0], mars[1])) {
                    // System.out.println("======= not Equals=========");
                    FileWriter fw = new FileWriter(path + "result_notEquals_"
                            + time, true);
                    fw.write(perLine);
                    fw.write(strlineseparator);
                    fw.flush();
                    fw.close();
                    // System.out.println(perLine);
                    // System.out.println(mars[0] + "," + mars[1]);
                    // System.out.println("======= not Equals=========");
                } else if ((int) mars[0] == 0 || (int) mars[1] == 0) {
                    FileWriter fw = new FileWriter(path + "result_0_0_" + time,
                            true);
                    fw.write(perLine);
                    fw.write(strlineseparator);
                    fw.flush();
                    fw.close();
                } else if (reportBean.isEquals(mars[0], mars[1])) {
                    FileWriter fw = new FileWriter(path + "result_equals_"
                            + time, true);
                    fw.write(perLine);
                    fw.write(strlineseparator);
                    fw.flush();
                    fw.close();
                }
                response.getEntity().getContent().close();
            } catch (Exception e) {
                e.printStackTrace();
                FileWriter fw = new FileWriter(path + "result_error_" + time,
                        true);
                fw.write(perLine);
                fw.write(strlineseparator);
                fw.flush();
                fw.close();
            } finally {

            }
        }
    }

    protected static Response processInputStream(InputStream is)
            throws IOException {
        DataInputStream dataInputStream = new DataInputStream(is);
        if (dataInputStream.readUnsignedShort() != 2) {
            throw new IOException("un recongnised protecol versoin");
        }
        int i = dataInputStream.readInt();
        int j = dataInputStream.readUnsignedShort();
        // System.out.println("get int i " + i + " j " + j);

        DelimitedInputStream delimitedInputStream;

        Object obj = null;
        if (j == 33024) {
            delimitedInputStream = new DelimitedInputStream(dataInputStream, i);
            obj = new PlainResponse(delimitedInputStream);
        } else if (j == 33025) {
            delimitedInputStream = new DelimitedInputStream(dataInputStream, i);
            obj = new MultipartResponse(delimitedInputStream);
        } else {
            dataInputStream.skipBytes(i);
            obj = null;
        }

        return (Response) obj;
    }

    private static GoogleHttpClient createHttpClient() {
        String userAgent = "GoogleMobile/1.0";
        GoogleHttpClient client = new GoogleHttpClient(userAgent, true);
        HttpParams params = client.getParams();
        HttpProtocolParams.setContentCharset(params, "UTF-8");

        // set the socket timeout
        int soTimeout = 60000;

        // if (true) {
        // System.out
        // .println("[HttpUtils] createHttpClient w/ socket timeout "
        // + soTimeout + " ms, " + ", UA=" + userAgent);
        // }
        HttpConnectionParams.setSoTimeout(params, soTimeout);
        return client;
    }

    private static byte[] makePostData() {
        ProtoBuf requestElement = new ProtoBuf(
                LocserverMessageTypes.GLOC_REQUEST_ELEMENT);
        if (listCellData != null && listCellData.size() > 0) {
            ProtoBuf protobuf1 = getCellProfile(listCellData);
            requestElement.setProtoBuf(GLocRequestElement.CELLULAR_PROFILE,
                    protobuf1);
        }

        if (listWifiData != null && listWifiData.size() > 0) {
            ProtoBuf wifiProfile = new ProtoBuf(GwifiMessageTypes.GWIFI_PROFILE);
            wifiProfile.setLong(GWifiProfile.TIMESTAMP, 1);
            wifiProfile.setInt(GWifiProfile.PREFETCH_MODE,
                    GPrefetchMode.PREFETCH_MODE_MORE_NEIGHBORS);

            int count = 0;
            for (WifiData s : listWifiData) {
                ProtoBuf wifiDevice = new ProtoBuf(
                        GwifiMessageTypes.GWIFI_DEVICE);
                wifiDevice.setString(GWifiDevice.MAC, s.bssid);
                wifiProfile.addProtoBuf(GWifiProfile.WIFI_DEVICES, wifiDevice);
                count++;
                if (count >= MAX_WIFI_TO_INCLUDE) {
                    break;
                }
            }

            requestElement.setProtoBuf(GLocRequestElement.WIFI_PROFILE,
                    wifiProfile);
        }

        // Request to send over wire
        ProtoBuf request = new ProtoBuf(LocserverMessageTypes.GLOC_REQUEST);
        request.addProtoBuf(GLocRequest.REQUEST_ELEMENTS, requestElement);

        // Create a Platform Profile
        ProtoBuf platformProfile = createPlatformProfile();
        request.setProtoBuf(GLocRequest.PLATFORM_PROFILE, platformProfile);

        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        try {
            request.outputTo(payload);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        // ByteToFile.getFile(payload.toByteArray(), "/sdcard",
        // "locate_wifi3.txt");
        // Creates request and a listener with a call back function
        // ProtoBuf reply = new ProtoBuf(LocserverMessageTypes.GLOC_REPLY);
        Request plainRequest = new PlainRequest(REQUEST_QUERY_LOC, (short) 0,
                payload.toByteArray());

        // ProtoRequestListener listener = new ProtoRequestListener(reply,
        // new ServiceCallback() {
        // public void onRequestComplete(Object result) {
        // ProtoBuf response = (ProtoBuf) result;
        // parseNetworkLocationReply(response, callback);
        //
        // }
        // });
        // plainRequest.setListener(listener);
        // try {
        // ByteToFile.getFile(InputStreamUtils.InputStreamTOByte(plainRequest
        // .getInputStream()), "/sdcard", "locate_wifi3_2.txt");
        // } catch (IOException e) {
        // // TODO Auto-generated catch block
        // e.printStackTrace();
        // }
        try {
            return InputStreamUtils.InputStreamTOByte(plainRequest
                    .getInputStream());
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    public static LocationCallback sCallback1 = new LocationCallback() {
        @Override
        public void Error(String msg) {
            System.out.println("ERROR: " + msg);
        }

        @Override
        public void GotLocation(String postData, double lat, double lon, int acc) {

            // double[] mars = TransformLocation.gps2mars(lat, lon);
            // System.out.println(String.format(
            // "storing location (%s)  mars lat,lon %f,%f  accuracy = %d",
            // postData, mars[0], mars[1], acc));
            // gps2addr(lat, lon);
        }
    };

    private static void gps2addr(double lat, double lng) {
        // "http://api.mobile.meituan.com/locate/v1/addr/gps/40.030993,116.411340"
        String strUrl1 = "http://api.mobile.meituan.com/locate/v1/addr/gps/";
        strUrl1 += lat + "," + lng;
        String[] params = {};
        Get<String> dataGet = new Get<String>(strUrl1, params);
        dataGet.setConvertor(new StringConvertor());
        String strResult = dataGet.getResult();
        System.out.println(strResult);

    }

    private static double[] parseNetworkLocationReply(ProtoBuf response) {
        double[] mars = new double[] { 0d, 0d };
        if (response == null) {
            // callback.Error("response is null");
            return mars;
        }

        int status1 = response.getInt(GLocReply.STATUS);
        if (status1 != ResponseCodes.STATUS_STATUS_SUCCESS) {
            // callback.Error("RPC failed with status " + status1);
            return mars;
        }

        if (response.has(GLocReply.PLATFORM_KEY)) {
            String platformKey = response.getString(GLocReply.PLATFORM_KEY);
            if (platformKey != null && !"".equals(platformKey)) {
                // setPlatformKey(platformKey);
            }
        }

        if (!response.has(GLocReply.REPLY_ELEMENTS)) {
            // callback.Error("no ReplyElement");
            return mars;
        }
        ProtoBuf replyElement = response.getProtoBuf(GLocReply.REPLY_ELEMENTS);

        int status2 = replyElement.getInt(GLocReplyElement.STATUS);
        if (status2 != ResponseCodes.STATUS_STATUS_SUCCESS
                && status2 != ResponseCodes.STATUS_STATUS_FAILED) {
            // callback.Error("failed with status " + status2);
            return mars;
        }

        double lat = 0, lng = 0;
        int mcc = -1, mnc = -1, cid = -1, lac = -1;
        int locType = -1;
        int acc = -1, alt = 0;

        // System.out
        // .println("getNetworkLocation(): Number of prefetched entries "
        // + replyElement
        // .getCount(GLocReplyElement.DEVICE_LOCATION));

        // most of the time there is only one response here, but loop through
        // all of them
        // just in case one of them is the real tower location and not just the
        // centroid

        int minaccuracy = 0;
        double acclat = 0;
        double acclng = 0;

        for (int i = 0; i < replyElement
                .getCount(GLocReplyElement.DEVICE_LOCATION); i++) {
            ProtoBuf device = replyElement.getProtoBuf(
                    GLocReplyElement.DEVICE_LOCATION, i);
            if (device.has(GDeviceLocation.LOCATION)) {
                ProtoBuf deviceLocation = device
                        .getProtoBuf(GDeviceLocation.LOCATION);
                if (deviceLocation.has(GLocation.LAT_LNG)) {
                    lat = deviceLocation.getProtoBuf(GLocation.LAT_LNG).getInt(
                            GLatLng.LAT_E7)
                            / E7;
                    lng = deviceLocation.getProtoBuf(GLocation.LAT_LNG).getInt(
                            GLatLng.LNG_E7)
                            / E7;
                }
                if (deviceLocation.has(GLocation.ACCURACY)) {
                    acc = deviceLocation.getInt(GLocation.ACCURACY);
                }

                if (deviceLocation.has(GLocation.ALTITUDE)) {
                    alt = deviceLocation.getInt(GLocation.ALTITUDE);
                }

                if (deviceLocation.has(GLocation.LOC_TYPE)) {
                    locType = deviceLocation.getInt(GLocation.LOC_TYPE);
                }
            }

            String strPostData = "";
            // get cell info
            if (device.has(GDeviceLocation.CELL)) {
                ProtoBuf deviceCell = device.getProtoBuf(GDeviceLocation.CELL);
                cid = deviceCell.getInt(GCell.CELLID);
                lac = deviceCell.getInt(GCell.LAC);
                if (deviceCell.has(GCell.MNC) && deviceCell.has(GCell.MCC)) {
                    mcc = deviceCell.getInt(GCell.MCC);
                    mnc = deviceCell.getInt(GCell.MNC);
                }
                strPostData = String.format("mcc %d mnc %d lac %d cid %d ",
                        mcc, mnc, lac, cid);
            }
            // get cell info
            if (device.has(GDeviceLocation.WIFI_DEVICE)) {
                ProtoBuf deviceCell = device
                        .getProtoBuf(GDeviceLocation.WIFI_DEVICE);
                String strMac = deviceCell.getString(GWifiDevice.MAC);

                strPostData = String.format("mac %s ", strMac);
            }

            // System.out.println(String.format(
            // "storing location (%s)  mars lat,lon %f,%f  accuracy = %d",
            // strPostData, lat, lng, acc));
            if (acc > 0 && (minaccuracy == 0 || acc < minaccuracy)) {
                acclat = lat;
                acclng = lng;
                minaccuracy = acc;
            }

            // if we have the actual tower location, break, otherwise keep going
            // just in case
            if (locType == GLocation.LOCTYPE_TOWER_LOCATION) {
                break;
            }
        }
        // System.out.println(String.format("  lat,lon %f,%f  accuracy = %d",
        // acclat, acclng, minaccuracy));
        mars = TransformLocation.gps2mars(acclat, acclng);
        // System.out.println(String.format("  mars lat,lon %f,%f  accuracy = %d",
        // mars[0], mars[1], minaccuracy));
        return mars;
    }

    private static ProtoBuf mPlatformProfile;

    private static ProtoBuf createPlatformProfile() {
        if (mPlatformProfile == null) {
            mPlatformProfile = new ProtoBuf(
                    GlocationMessageTypes.GPLATFORM_PROFILE);
            mPlatformProfile.setString(GPlatformProfile.VERSION,
                    APPLICATION_VERSION);
            mPlatformProfile.setString(GPlatformProfile.PLATFORM,
                    PLATFORM_BUILD);
        }

        // Add Locale
        Locale locale = Locale.getDefault();
        if ((locale != null) && (locale.toString() != null)) {
            mPlatformProfile.setString(GPlatformProfile.LOCALE,
                    locale.toString());
        }

        // // Add Platform Key
        // String platformKey = null;
        // if (platformKey != null && !"".equals(platformKey)) {
        // mPlatformProfile.setString(GPlatformProfile.PLATFORM_KEY,
        // platformKey);
        // }

        // Clear out cellular platform profile
        mPlatformProfile.setProtoBuf(
                GPlatformProfile.CELLULAR_PLATFORM_PROFILE, null);

        return mPlatformProfile;
    }

    private static ProtoBuf getCellProfile(List<CellData> cells) {
        Date now = new Date();

        ProtoBuf cellularProfile = new ProtoBuf(
                GcellularMessageTypes.GCELLULAR_PROFILE);
        cellularProfile.setLong(GCellularProfile.TIMESTAMP, now.getTime());
        cellularProfile.setInt(GCellularProfile.PREFETCH_MODE,
                GPrefetchMode.PREFETCH_MODE_MORE_NEIGHBORS);
        CellData primary = cells.get(0);
        ProtoBuf primaryCell = new ProtoBuf(GcellularMessageTypes.GCELL);
        primaryCell.setInt(GCell.LAC, primary.lac);
        primaryCell.setInt(GCell.CELLID, primary.cid);
        primaryCell.setInt(GCell.MCC, primary.mcc);
        primaryCell.setInt(GCell.MNC, primary.mnc);
        primaryCell.setInt(GCell.RSSI, primary.signalStrength);
        if (primary.psc != -1) {
            primaryCell.setInt(GCell.PRIMARY_SCRAMBLING_CODE, primary.psc);
        }
        primaryCell.setInt(GCell.RADIO_TYPE,
                getGCellRadioType(primary.getRadioType()));

        cellularProfile.addProtoBuf(GCellularProfile.PRIMARY_CELL, primaryCell);

        // 第一条已经不需要了。从第二条开始才是NEIGHBORS
        for (int i = 1; i < listCellData.size(); i++) {
            CellData cell = listCellData.get(i);
            ProtoBuf historical = new ProtoBuf(GcellularMessageTypes.GCELL);
            historical.setInt(GCell.LAC, cell.lac);
            historical.setInt(GCell.CELLID, cell.cid);
            historical.setInt(GCell.MCC, cell.mcc);
            historical.setInt(GCell.MNC, cell.mnc);
            if (cell.psc != -1) {
                historical.setInt(GCell.PRIMARY_SCRAMBLING_CODE, cell.psc);
            }
            historical.setInt(GCell.RADIO_TYPE,
                    getGCellRadioType(cell.getRadioType()));
            cellularProfile.addProtoBuf(GCellularProfile.NEIGHBORS, historical);
        }

        return cellularProfile;
    }

    public static int getGCellRadioType(int radioType) {
        byte byte0 = -1;
        if (radioType == 1) {
            // 移动
            byte0 = 3;
        } else if (radioType == 2) {
            // cdma
            byte0 = 4;
        } else if (radioType == 3) {
            // 联通
            byte0 = 5;
        }
        return byte0;
    }

    private static List<WifiData> listWifiData = new ArrayList<WifiData>();
    private static List<CellData> listCellData = new ArrayList<CellData>();

    private static void initwifidata() {
        String[] mac = { "00:27:22:6c:14:18", "6c:e8:73:d0:c3:8c",
                "e4:ce:8f:23:02:fc", "e4:ce:8f:4a:90:68", "02:27:22:6c:14:18",
                "00:27:22:6c:14:9e", "60:c5:47:9a:28:6c", "02:27:22:6c:14:9e",
                "00:27:22:6c:14:a4", "02:27:22:6c:14:a4", "00:27:22:b7:6d:2b",
                "06:27:22:b7:6d:2b", "b8:8d:12:24:24:04", "38:22:d6:87:fa:f0",
                "00:27:22:51:6e:e9", "dc:9f:db:1c:62:ba", "de:9f:db:1c:62:ba",
                "06:27:22:51:70:58", "06:27:22:b7:70:29", "00:27:22:b7:6d:32",
                "06:27:22:b7:6d:32" };
        mac = new String[] { "c8:3a:35:17:d5:78" };
        final int[] signal_strength = { -58, -48, -50, -70, -58, -74, -73, -73,
                -74, -72, -83, -82, -74, -66, -84, -73, -77, -89, -91, -80, -78 };
        // init wifi data
        for (int i = 0; i < mac.length; i++) {
            WifiData wifidata1 = new WifiData();
            wifidata1.bssid = mac[i];
            wifidata1.level = signal_strength[i];
            listWifiData.add(wifidata1);
        }
    }

    private static void initcdmacelldata() {
        // init cell id
        // 百度定位只有一组cell数据
        CellData celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 13824;
        celldata.lac = 1;
        celldata.cid = 1400;
        celldata.time = System.currentTimeMillis();
        celldata.radioType = "cdma";
        listCellData.add(celldata);
    }

    private static void initwcdmacelldata() {
        // init cell id
        // 百度定位只有一组cell数据
        CellData celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 1;
        // celldata.psc = 386;
        // celldata.lac = 54158;
        // celldata.cid = 268435455;
        celldata.lac = 54131;
        celldata.cid = 122039354;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
    }

    private static void initgsmcelldata() {
        // init cell id
        // 百度定位只有一组cell数据
        CellData celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 4353;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);

        celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 5569;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
        celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 65;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
        celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 5491;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
        celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 4369;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
        celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 4434;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
        celldata = new CellData();
        celldata.mcc = 460;
        celldata.mnc = 0;
        celldata.lac = 6144;
        celldata.cid = 4355;
        celldata.time = System.currentTimeMillis();
        listCellData.add(celldata);
    }

    private static String getIp() {
        StringBuffer sb = new StringBuffer();
        sb.append(getIpInt());
        sb.append(":");
        sb.append(getIpInt());
        sb.append(":");
        sb.append(getIpInt());
        sb.append(":");
        sb.append(getIpInt());
        return sb.toString();
    }

    private static int getIpInt() {
        int ip = (int) Math.round(Math.random() * 255);

        return ip;
    }
    private static class NoCookieHttpClient extends DefaultHttpClient {
        public NoCookieHttpClient(
                final ClientConnectionManager conman) {
            super(conman);
        }
        
        public HttpContext createHttpContext() {
            HttpContext context = super.createHttpContext();
            context.setAttribute(
                    ClientContext.COOKIE_STORE,
                    new BasicCookieStore());
            return context;
        }

    };
}
