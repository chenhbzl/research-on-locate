/*jadclipse*/// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.

package test.main;

public class CellData {

    public CellData() {
    }

    public int cid;
    public int lac;
    public int mcc;
    public int mnc;
    public int psc = -1;
    public long time;
    public String radioType = "gsm";
    public int signalStrength;

    public int getRadioType() {
        if ("cdma".equals(radioType)) {
            return 2;
        } else if (mnc == 1) {
            return 3;
        } else {
            return 1;
        }
    }
}

/*
 * DECOMPILATION REPORT
 * 
 * Decompiled from:
 * /Users/chenhongbing/dev/workspace/TestBaiduLocate/libs/location-1.0.4.jar
 * Total time: 21 ms Jad reported messages/errors: Exit status: 0 Caught
 * exceptions:
 */